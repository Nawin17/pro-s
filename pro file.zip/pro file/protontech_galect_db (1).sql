-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 01, 2024 at 04:57 PM
-- Server version: 8.0.39
-- PHP Version: 8.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `protontech_galect_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `aptitude_test`
--

CREATE TABLE `aptitude_test` (
  `id` int NOT NULL,
  `question` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `option_1` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `option_2` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `option_3` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `option_4` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `answer` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `aptitude_test`
--

INSERT INTO `aptitude_test` (`id`, `question`, `option_1`, `option_2`, `option_3`, `option_4`, `answer`) VALUES
(9, 'A person crosses a 600 m long street in 5 minutes. What is his speed in km per hour?', '3.6', '7.2', '8.4', '10', '7.2'),
(10, 'A man complete a journey in 10 hours. He travels first half of the journey at the rate of 21 km/hr and second half at the rate of 24 km/hr. Find the total journey in km.', '220 km', '224 km', '230 km', '234 km', '224 km'),
(11, 'A train running at the speed of 60 km/hr crosses a pole in 9 seconds. What is the length of the train?', '120 metres', '180 metres', '324 metres', '150 metres', '150 metres'),
(12, 'A train 240 m long passes a pole in 24 seconds. How long will it take to pass a platform 650 m long?', '65 sec', '89 sec', '100 sec', '150 sec', '89 sec'),
(13, 'It was Sunday on Jan 1, 2006. What was the day of the week Jan 1, 2010?', 'Sunday', 'Saturday', 'Friday', 'Wednesday', 'Friday'),
(14, 'The calendar for the year 2007 will be the same for the year:', '2014', '2016', '2017', '2018', '2018'),
(15, 'A vendor bought toffees at 6 for a rupee. How many for a rupee must he sell to gain 20%?', '3', '4', '5', '6', '5'),
(16, 'A man buys a cycle for Rs. 1400 and sells it at a loss of 15%. What is the selling price of the cycle?', 'Rs. 1090', 'Rs. 1160', 'Rs. 1190', 'Rs. 1202', 'Rs. 1190'),
(17, 'A, B and C can do a piece of work in 20, 30 and 60 days respectively. In how many days can A do the work if he is assisted by B and C on every third day?', '12 days', '15 days', '16 days', '18 days', '15 days'),
(18, 'A alone can do a piece of work in 6 days and B alone in 8 days. A and B undertook to do it for Rs. 3200. With the help of C, they completed the work in 3 days. How much is to be paid to C?', '375', '400', '600', '800', '400'),
(19, 'In a certain store, the profit is 320% of the cost. If the cost increases by 25% but the selling price remains constant, approximately what percentage of the selling price is the profit?', '0.3', '0.7', '1', '2.5', '0.7'),
(20, 'The cost price of 20 articles is the same as the selling price of x articles. If the profit is 25%, then the value of x is:', '15', '16', '18', '25', '16'),
(21, 'In a 100 m race, A beats B by 10 m and C by 13 m. In a race of 180 m, B will beat C by:', '5.4m', '4.5 m', '5 m', '6 m', '6 m'),
(22, 'A shopkeeper expects a gain of 22.5% on his cost price. If in a week, his sale was of Rs. 392, what was his profit?', 'rs.88.20', 'rs. 70', 'rs 72', 'rs  82.50', 'Rs . 72'),
(23, 'A fruit seller had some apples. He sells 40% apples and still has 420 apples. Originally, he had:', '588 apples', '600 apples', '672 apples', '700 apples', '700 apples'),
(24, 'The population of a town increased from 1,75,000 to 2,62,500 in a decade. The average percent increase of population per year is:', '0.04', '0.05', '0.06', '0.0823', '0.05'),
(25, 'In the first 10 overs of a cricket game, the run rate was only 3.2. What should be the run rate in the remaining 40 overs to reach the target of 282 runs?', '6.25', '6.5', '6.75', '7', '6.25'),
(26, 'The average of 20 numbers is zero. Of them, at the most, how many may be greater than zero?', '0', '1', '10', '19', '19'),
(27, 'The average age of husband, wife and their child 3 years ago was 27 years and that of wife and the child 5 years ago was 20 years. The present age of the husband is:', '35 years', '40 years', '50 years', 'None ofthe above', '40 years'),
(28, 'The average weight of A, B and C is 45 kg. If the average weight of A and B be 40 kg and that of B and C be 43 kg, then the weight of B is:', '17 kg', '20 kg', '31 kg', '26 kg', '31 kg'),
(29, 'A library has an average of 510 visitors on Sundays and 240 on other days. The average number of visitors per day in a month of 30 days beginning with a Sunday is:', '250', '285', '280', '276', '285'),
(30, 'If the average marks of three batches of 55, 60 and 45 students respectively is 50, 55, 60, then the average marks of all the students is:', '53.33', '54.68', '55', 'None of these', '54.68'),
(31, 'A hall is 15 m long and 12 m broad. If the sum of the areas of the floor and the ceiling is equal to the sum of the areas of four walls, the volume of the hall is:', '720', '900', '1200', '1800', '1200'),
(32, '66 cubic centimetres of silver is drawn into a wire 1 mm in diameter. The length of the wire in metres will be:', '84', '90', '168', '336', '84'),
(33, 'A began a business with Rs. 85,000. He was joined afterwards by B with Rs. 42,500. For how much period does B join, if the profits at the end of the year are divided in the ratio of 3 : 1?', '4 months', '5 months', '6 months', '8 months', '8 months'),
(34, 'The sum of ages of 5 children born at the intervals of 3 years each is 50 years. What is the age of the youngest child?', '4 years', '8 years', '10 years', 'None of these', '4 years'),
(35, 'A is two years older than B who is twice as old as C. If the total of the ages of A, B and C be 27, then how old is B?', '7', '8', '9', '10', '10'),
(36, 'An error 2% in excess is made while measuring the side of a square. The percentage of error in the calculated area of the square is:', '0.02', '0.0202', '0.04', '0.0404', '0.0404'),
(37, 'The ratio between the perimeter and the breadth of a rectangle is 5 : 1. If the area of the rectangle is 216 sq. cm, what is the length of the rectangle?', '16 cm', '18 cm', '24 cm', 'None of these', '18 cm'),
(38, 'The percentage increase in the area of a rectangle, if each of its sides is increased by 20% is:', '0.4', '0.42', '0.44', '0.46', '0.44'),
(39, 'A man walked diagonally across a square lot. Approximately, what was the percent saved by not walking along the edges?', '20', '24', '30', '33', '30'),
(40, 'Find out the wrong number in the given sequence of numbers. 52, 51, 48, 43, 34, 27, 16', '27', '34', '43', '48', '34'),
(41, 'A hollow iron pipe is 21 cm long and its external diameter is 8 cm. If the thickness of the pipe is 1 cm and iron weighs 8 g/cm3, then the weight of the pipe is:', '3.6 kg', '3.696 kg', '36 kg', '36.9 kg', '3.696 kg'),
(42, 'If one-third of one-fourth of a number is 15, then three-tenth of that number is:', '35', '36', '45', '54', '54'),
(43, 'The difference between a two-digit number and the number obtained by interchanging the positions of its digits is 36. What is the difference between the two digits of that number?', '3', '4', '9', 'None of these', '4'),
(44, 'A number consists of two digits. If the digits interchange places and the new number is added to the original number, then the resulting number will be divisible by:', '3', '5', '9', '11', '11'),
(45, 'The product of two numbers is 2028 and their H.C.F. is 13. The number of such pairs is:', '1', '2', '3', '4', '2'),
(46, 'The least multiple of 7, which leaves a remainder of 4, when divided by 6, 9, 15 and 18 is:', '74', '84', '184', '364', '364'),
(47, 'The cube root of .000216 is:', '0.6', '0.06', '77', '87', '0.06'),
(48, 'The least perfect square, which is divisible by each of 21, 36 and 66 is:', '213444', '214344', '214434', '231444', '213444'),
(49, '3 pumps, working 8 hours a day, can empty a tank in 2 days. How many hours a day must 4 pumps work to empty the tank in 1 day?', '9', '10', '11', '12', '12'),
(50, '39 persons can repair a road in 12 days, working 5 hours a day. In how many days will 30 persons, working 6 hours a day, complete the work?', '10', '13', '14', '15', '13'),
(51, 'In a class, there are 15 boys and 10 girls. Three students are selected at random. The probability that 1 girl and 2 boys are selected, is:', '25/117', '21/46', '150', '325', '21/46'),
(52, 'A and B take part in 100 m race. A runs at 5 kmph. A gives B a start of 8 m and still beats him by 8 seconds. The speed of B is:', '5.15 kmph', '4.14 kmph', '4.25 kmph', '4.4 kmph', '4.14 kmph'),
(53, 'At a game of billiards, A can give B 15 points in 60 and A can give C to 20 points in 60. How many points can B give C in a game of 90?', '30 points', '20 points', '10 points', '12 points', '10 points'),
(54, 'The H.C.F. of two numbers is 23 and the other two factors of their L.C.M. are 13 and 14. The larger of the two numbers is:', '276', '299', '322', '345', '322'),
(55, 'Six bells commence tolling together and toll at intervals of 2, 4, 6, 8 10 and 12 seconds respectively. In 30 minutes, how many times do they toll together ?', '4', '10', '15', '16', '16'),
(56, 'At 3:40, the hour hand and the minute hand of a clock form an angle of:', '120°', '125°', '130°', '135°', '130°'),
(57, 'In a 100 m race, A can beat B by 25 m and B can beat C by 4 m. In the same race, A can beat C by:', '21 m', '26 m', '28 m', '29 m', '28 m'),
(58, 'In a game of 100 points, A can give B 20 points and C 28 points. Then, B can give C:', '8 points', '10 points', '14 points', '40 points', '10 points'),
(59, 'Rs. 20 is the true discount on Rs. 260 due after a certain time. What will be the true discount on the same sum due after half of the former time, the rate of interest being the same?', 'Rs. 10', 'Rs. 10.40', 'Rs. 15.20', 'Rs. 13', 'Rs. 10.40'),
(60, 'The present worth of Rs. 1404 due in two equal half-yearly installments at 8% per annum simple interest is:', 'Rs. 1325', 'Rs. 1300', 'Rs. 1350', 'Rs. 1500', 'Rs. 1325');

-- --------------------------------------------------------

--
-- Table structure for table `candidate_list`
--

CREATE TABLE `candidate_list` (
  `id` int NOT NULL,
  `name` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `dob` date NOT NULL,
  `gender` enum('male','female','other') COLLATE utf8mb4_general_ci NOT NULL,
  `college` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `mobile` varchar(12) COLLATE utf8mb4_general_ci NOT NULL,
  `qualification` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `domain` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `location` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `pincode` int NOT NULL,
  `dot1` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `dot` varchar(20) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tot` varchar(10) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `otp` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `otp_count` int DEFAULT NULL,
  `login_count` enum('0','1') COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `date_added` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `candidate_list`
--

INSERT INTO `candidate_list` (`id`, `name`, `email`, `dob`, `gender`, `college`, `mobile`, `qualification`, `domain`, `location`, `pincode`, `dot1`, `dot`, `tot`, `otp`, `otp_count`, `login_count`, `date_added`) VALUES
(5, 'Mohan Reddy', 'mohanreddym796@gmail.com', '2000-08-03', 'male', 'proton', '6361639350', 'B E', 'Php', 'Bangalore', 560045, '2023-12-18 00:00:00', '18-Dec-23', '12:15 PM', 'UFZT5EYL', 2, '1', '2023-12-18 06:43:42'),
(9, 'Dinesh Kumar', 'dineshkarthivel@gmail.com', '1999-12-01', 'male', 'proton', '8489482709', 'B E', 'Php', 'Bangalore', 560045, '2023-12-19 00:00:00', '19-Dec-23', '01:00 PM', 'iBAOXM7K', 1, '1', '2023-12-19 07:03:59'),
(10, 'Goutameshwar Charodi', 'gauthamcharodi23@gmail.com', '2001-12-20', 'male', 'proton', '9663844522', 'B E', 'Php', 'Bangalore', 560045, '2023-12-20 00:00:00', '20-Dec-23', '11:00 AM', '8ebLsrBO', 1, '1', '2023-12-20 05:22:28'),
(11, 'Nitish Mani', 'nitishmani1111@gmail.com', '2001-08-01', 'male', 'proton', '9080994916', 'B E', 'Php', 'Bangalore', 560045, '2023-12-20 00:00:00', '20-Dec-23', '11:00 AM', '0ycNTG4L', 1, '1', '2023-12-20 05:37:00'),
(18, 'Saba Afreen', 'afreensaba97@gmail.com', '1997-12-03', 'female', 'proton', '9844403337', 'B E', 'Php', 'Bangalore', 560045, '2023-12-20 00:00:00', '20-Dec-23', '12:30 PM', 'kZCJ3wHi', 1, '1', '2023-12-20 06:56:07'),
(19, 'Pavithra B S', 'pavithrabs2000@gmail.com', '2000-07-08', 'female', 'proton', '6361382581', 'B E', 'Php', 'Bangalore', 560045, '2023-12-21 00:00:00', '21-Dec-23', '12:00 PM', 'HwOeb9va', 1, '1', '2023-12-21 05:59:52'),
(20, 'Deepa S K', 'deepask253@gmail.com', '2001-03-25', 'female', 'proton', '8197933679', 'B E', 'Php', 'Bangalore', 560045, '2023-12-21 00:00:00', '21-Dec-23', '12:00 PM', 'WXNxEhel', 1, '1', '2023-12-21 06:00:45'),
(24, 'Kaushal S', 'shivaramkaushal@gmail.com', '1999-12-02', 'male', 'proton', '8892371330', 'B E', 'Php', 'Bangalore', 560045, '2023-12-22 00:00:00', '22-Dec-23', '11:00 AM', 'Ulenmwmi', 3, '1', '2023-12-22 05:03:23'),
(27, 'S Poomani', 'poomaniselvam518@gmail.com', '1999-12-14', 'male', 'proton', '8680800512', 'MBA', 'Php', 'Bangalore', 560045, '2023-12-26 00:00:00', '26-Dec-23', '12:00 PM', 'VGvOtJYX', 2, '1', '2023-12-26 06:00:50'),
(28, 'Syed Haris', 'syed567syed@gmail.com', '1997-12-10', 'male', 'proton', '8095207317', 'B E', 'Php', 'Bangalore', 560045, '2023-12-26 00:00:00', '26-Dec-23', '12:00 PM', 'DMVv7ike', 1, '1', '2023-12-26 06:07:34'),
(29, 'pant', 'pan@outlook.com', '2023-01-01', 'male', 'proton', '9876543210', 'b.com', 'adf', 'Bangalroe', 560017, '2023-12-28 00:00:00', '28-Dec-23', '02:03 PM', 'DHYgRRy6', 1, '1', '2023-12-28 07:32:30'),
(33, 'Darshan Naik', 'naikdarshan547@gmail.com', '2000-12-27', 'male', 'proton', '8197221630', 'B Tech', 'Php', 'Bangalore', 560045, '2023-12-27 00:00:00', '27-Dec-23', '12:00 PM', 'bTsWU6YT', 1, '1', '2023-12-27 05:43:53'),
(34, 'Mahammad Rafi', 'mahammadrafi1506@gmail.com', '2001-12-29', 'male', 'proton', '7993783637', 'B Tech', 'Php', 'Bangalore', 560045, '2023-12-29 00:00:00', '29-Dec-23', '11:00 AM', 'XmwKRXo2', 1, '1', '2023-12-29 05:11:00'),
(35, 'Ganesha C', 'ganeshashet24@gmail.com', '2000-12-29', 'male', 'proton', '9591813175', 'MCA', 'Php', 'Bangalore', 560045, '2023-12-29 00:00:00', '29-Dec-23', '11:00 AM', 'GAKls1xd', 1, '1', '2023-12-29 05:26:33'),
(36, 'Srivatsa B C', 'Srivathsa901@gmail.com', '2000-12-06', 'male', 'proton', '9590237665', 'B E', 'Php', 'Bangalore', 560045, '2023-12-29 00:00:00', '29-Dec-23', '11:00 AM', '8lNjFyeH', 1, '1', '2023-12-29 05:28:10'),
(42, 'Abhishek S R', 'yabhishekabi1@gmail.com', '2000-11-12', 'male', 'proton', '9380297600', 'MSC', 'Php', 'Bangalore', 560045, '2024-01-02 00:00:00', '02-Jan-24', '11:00 AM', 'PEeiAzpB', 2, '1', '2024-01-02 04:54:18'),
(43, 'Sandhya Koudi', 'sandhyakoudi7@gmail.com', '2001-01-02', 'female', 'proton', '7349697801', 'BCA', 'Php', 'Bangalore', 560045, '2024-01-03 00:00:00', '03-Jan-24', '11:00 AM', 'tAYyqijt', 1, '1', '2024-01-02 05:21:48'),
(44, 'Tejas V', 'tejasvijendra@gmail.com', '2001-09-09', 'male', 'proton', '6362529110', 'B E', 'Php', 'Bangalore', 560045, '2024-01-02 00:00:00', '02-Jan-24', '12:00 PM', 'jypcLGy7', 1, '1', '2024-01-02 05:59:18'),
(45, 'Shanmukha K', 'shanmukhakuner@gmail.com', '2001-01-02', 'male', 'proton', '6363361571', 'B E', 'Php', 'Bangalore', 560045, '2024-01-02 00:00:00', '02-Jan-24', '12:00 PM', 'V9xFD1G8', 1, '1', '2024-01-02 06:01:59'),
(46, 'Jeevan Y', 'jeevanofficial@gmail.com', '2001-01-02', 'male', 'proton', '9483296559', 'B E', 'Php', 'Bangalore', 560045, '2024-01-02 00:00:00', '02-Jan-24', '12:00 PM', 'Ro5TfC1v', 2, '1', '2024-01-02 06:13:03'),
(47, 'shreyash', 'shrey@outlook.com', '2023-01-01', 'male', 'proton', '9876543210', 'B.tech', 'asdfas', 'Bangalroe', 560017, '2024-01-02 00:00:00', '02-Jan-24', '04:55 PM', 'm7JlDFnY', 1, '1', '2024-01-02 10:25:40'),
(50, 'Vivekananda H S', 'vivekgowda997@gmail.com', '2000-07-27', 'male', 'proton', '7338101330', 'B E', 'Php', 'Bangalore', 560045, '2024-01-03 00:00:00', '03-Jan-24', '11:00 AM', 'rgACtdW1', 1, '1', '2024-01-03 05:08:19'),
(52, 'Hema', 'gsh62388@gmail.com', '2000-01-10', 'female', 'proton', '8217411630', 'BCA', 'Php', 'Bangalore', 560045, '2024-01-03 00:00:00', '03-Jan-24', '11:00 AM', 'KUK4CorD', 2, '1', '2024-01-03 05:27:51'),
(53, 'Jeevan D', 'jeevanjai55@gmail.com', '2001-01-03', 'male', 'proton', '7338472595', 'B E', 'Php', 'Bangalore', 560045, '2024-01-03 00:00:00', '03-Jan-24', '11:30 AM', 'TwiBRATy', 1, '1', '2024-01-03 05:43:47'),
(54, 'Vaishnavi', 'vaishnavianegundi393@gmail.com', '2001-01-03', 'female', 'proton', '7026254005', 'BCA', 'Php', 'Bangalore', 560045, '2024-01-03 00:00:00', '03-Jan-24', '11:30 AM', 'CSD2fiSf', 2, '1', '2024-01-03 05:41:51'),
(58, 'Rajyalakshmi Mekala', 'mekalarajyalakshmi55@gmail.com', '2001-01-03', 'female', 'proton', '9966336652', 'BSC', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '11:00 AM', 'YyiStweY', 2, '1', '2024-01-04 05:09:45'),
(59, 'Sree Harshitha', 'sakeharshitha678@gmail.com', '2001-01-04', 'female', 'proton', '8008931337', 'MCA', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '11:00 AM', 'Uew7RUqv', 1, '1', '2024-01-04 05:15:20'),
(60, 'Harikrishna Chakali', 'harikrishna32031@gmail.com', '2001-07-15', 'male', 'proton', '6309734402', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '11:00 AM', 'nRchMtda', 1, '1', '2024-01-04 04:58:48'),
(63, 'Mallikarjuna', 'hokranimallikarjuna@gmail.com', '2001-01-04', 'male', 'proton', '6366283754', 'B E', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '11:00 AM', 'qqzMgUse', 1, '1', '2024-01-04 05:26:52'),
(64, 'Jayanth N', 'jayanthnkallahalli@gmail.com', '2001-01-03', 'male', 'proton', '8553091100', 'B E', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '11:00 AM', '6NV8Zjcz', 1, '1', '2024-01-04 05:24:30'),
(66, 'Bhavya', 'bhavyakrish2001@gmail.com', '2001-01-04', 'female', 'proton', '9611417344', 'B E', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '12:00 PM', 'h7ORYpBN', 3, '1', '2024-01-04 05:58:49'),
(67, 'Boomika', 'boomikap335@gmail.com', '2001-01-04', 'female', 'proton', '8660983382', 'B E', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '12:00 PM', '1FQvXspT', 1, '1', '2024-01-04 06:02:48'),
(69, 'Chandrakanti Malik', 'chandrakantimalik11@gmail.com', '2001-01-03', 'female', 'proton', '9337046105', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '12:00 PM', 'B59RFfur', 1, '1', '2024-01-04 06:12:33'),
(70, 'Anuragh', 'anurag.kadri@gmail.com', '2001-01-04', 'male', 'proton', '9110432699', 'B E', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '12:00 PM', 'jHYeCoLu', 1, '1', '2024-01-04 06:19:35'),
(71, 'Hrushikesh', 'hrushikeshpradhan055@gmail.com', '2001-01-04', 'male', 'proton', '9938601859', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '12:00 PM', '3QRTCTZ4', 1, '1', '2024-01-04 06:20:15'),
(72, 'Hanumateja', 'hanumatheja382@gmail.com', '2001-01-04', 'male', 'proton', '9390976691', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '12:00 PM', 'QR3LwuLt', 2, '1', '2024-01-04 06:24:41'),
(73, 'Ashwini', 'chottuu7274@gmail.com', '2000-01-04', 'female', 'proton', '7204968828', 'B E', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '12:00 PM', 'mfaQVWC3', 1, '1', '2024-01-04 06:26:06'),
(74, 'Karthik D S', 'dskarthi2706@gmail.com', '1990-06-27', 'male', 'proton', '8825976266', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '03:00 PM', 'Y8G5Z4LD', 1, '1', '2024-01-04 09:13:51'),
(75, 'Sahana B M', 'sahanbmahadevappa@gmail.com', '2002-01-04', 'female', 'proton', '8105182949', 'B E', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '03:00 PM', 'Tn9Lo5g7', 1, '1', '2024-01-04 09:15:02'),
(76, 'Navyashree', 'klnavya2000@gmail.com', '2001-01-04', 'female', 'proton', '9353639952', 'B E', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '03:00 PM', 'ltscJJnR', 1, '1', '2024-01-04 09:13:23'),
(77, 'Haritha', 'nagishettyharitha304@gmail.com', '2001-01-04', 'female', 'proton', '8367632309', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '03:00 PM', 'ocwxbZRS', 1, '1', '2024-01-04 09:30:02'),
(78, 'Madhavi', 'madhusamanuri7@gmail.com', '2001-01-04', 'female', 'proton', '9550376142', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '03:00 PM', 'R0hzZNsk', 2, '1', '2024-01-04 09:29:12'),
(79, 'Pavan', 'ppk152000@gmail.com', '1998-01-01', 'male', 'proton', '8374614450', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '03:00 PM', 'TsOwU63h', 1, '1', '2024-01-04 09:28:20'),
(80, 'Nithyashree', 'nithyahrees2242000@gmail.com', '2000-04-22', 'female', 'proton', '7019282835', 'B E', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '03:00 PM', 'cnHAkuNK', 2, '1', '2024-01-04 09:43:27'),
(81, 'Logeshwaran M', 'logeshw748@gmail.com', '2001-01-04', 'male', 'proton', '9677752727', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-04 00:00:00', '04-Jan-24', '03:00 PM', 'o7JF9h7h', 1, '1', '2024-01-04 09:41:43'),
(82, 'Sandhya R B', 'sandhyarb351@gmail.com', '2000-01-05', 'female', 'proton', '7259252051', 'B E', 'Php', 'Bangalore', 560045, '2024-01-05 00:00:00', '05-Jan-24', '11:00 AM', 'sanBuFQZ', 1, '1', '2024-01-05 05:03:02'),
(83, 'Vijetha', 'vijethasmeti1092@gmail.com', '2000-01-05', 'male', 'proton', '8970070659', 'B E', 'Php', 'Bangalore', 560045, '2024-01-05 00:00:00', '05-Jan-24', '11:00 AM', 'XKrooiZC', 1, '1', '2024-01-05 05:03:17'),
(84, 'Sharath R', 'arsharath02@gmail.com', '2001-01-05', 'male', 'proton', '9360707506', 'B E', 'Php', 'Bangalore', 560045, '2024-01-05 00:00:00', '05-Jan-24', '11:00 AM', 'RLieM1A6', 1, '1', '2024-01-05 05:08:16'),
(85, 'Vidya', 'vidyasm54@gmail.com', '2001-01-05', 'female', 'proton', '7619594096', 'B E', 'Php', 'Bangalore', 560045, '2024-01-05 00:00:00', '05-Jan-24', '11:00 AM', 'NW9hrzQs', 1, '1', '2024-01-05 05:17:59'),
(86, 'K Safiya', 'kamulurisafiya@gmail.com', '2001-01-05', 'female', 'proton', '7989264438', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-05 00:00:00', '05-Jan-24', '11:00 AM', 'TWv6FEuR', 2, '1', '2024-01-05 05:20:12'),
(87, 'Ameen Ulla Rahim', 'ameenulrooh98@gmail.com', '1998-01-14', 'male', 'proton', '8073720181', 'B E', 'Php', 'Bangalore', 560045, '2024-01-05 00:00:00', '05-Jan-24', '11:30 AM', 'EXV5zPoE', 1, '1', '2024-01-05 05:53:58'),
(90, 'ARUNRAJ A', 'antonyarunraj@gmail.com', '1998-01-01', 'male', 'proton', '9994354007', 'B E', 'Php', 'Bangalore', 560045, '2024-01-09 00:00:00', '09-Jan-24', '11:00 AM', 'zDzfhvF7', 1, '1', '2024-01-09 04:53:25'),
(91, 'Sasikumar Thuraka', 'thurakasasikumar507@gmail.com', '2001-01-09', 'male', 'proton', '6304782748', 'MCA', 'Php', 'Bangalore', 566045, '2024-01-09 00:00:00', '09-Jan-24', '11:30 AM', 'dZXdbFel', 1, '1', '2024-01-09 05:41:13'),
(93, 'Achyuth Adabala', 'achyuthadabala@gmail.com', '1998-01-07', 'male', 'proton', '8328281081', 'B E', 'Php', 'Bangalore', 560045, '2024-01-09 00:00:00', '09-Jan-24', '11:30 AM', 'dklpYqTx', 1, '1', '2024-01-09 05:47:28'),
(95, 'Laxmikanth', 'laxmikanthpatil7777@gmail.com', '1998-01-09', 'male', 'proton', '8431337510', 'B E', 'Php', 'Bangalore', 560045, '2024-01-09 00:00:00', '09-Jan-24', '11:30 AM', 'xPHbEXgw', 2, '1', '2024-01-09 05:54:12'),
(96, 'Rishabh Raj', 'kingrishabh16@gmail.com', '1998-01-09', 'male', 'proton', '9155459545', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-09 00:00:00', '09-Jan-24', '12:00 PM', 'fyfNiU1x', 1, '1', '2024-01-09 06:10:06'),
(97, 'Srinivasa Reddy', 'elakotisrinu48@gmail.com', '2002-01-01', 'male', 'proton', '9014781995', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-09 00:00:00', '09-Jan-24', '12:00 PM', 'xSu6sTLx', 1, '1', '2024-01-09 06:10:49'),
(98, 'Indra Sena', 'indrasena197@gmail.com', '2002-01-09', 'male', 'proton', '9963276024', 'BCA', 'Php', 'Bangalore', 560045, '2024-01-09 00:00:00', '09-Jan-24', '12:00 PM', 'YKFnF7HT', 1, '1', '2024-01-09 06:09:58'),
(99, 'Rajshekhar', 'mrajasekhar9676@gmail.com', '1999-01-09', 'male', 'proton', '9676048900', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-09 00:00:00', '09-Jan-24', '12:00 PM', 'oHbZc68Z', 2, '1', '2024-01-09 06:08:32'),
(100, 'Venkata Surendra', 'venkatasurendra70@gmail.com', '2001-01-09', 'male', 'proton', '8247380327', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-09 00:00:00', '09-Jan-24', '12:00 PM', '0G0e7fws', 1, '1', '2024-01-09 06:26:35'),
(101, 'Sreekanth', 'sreekanth.t053@gmail.com', '2002-01-09', 'male', 'proton', '9491951967', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-09 00:00:00', '09-Jan-24', '12:00 PM', '1f1Tim2z', 1, '1', '2024-01-09 06:23:35'),
(102, 'Aarthi M', 'aarthi2000cse@gmail.com', '1998-01-09', 'female', 'proton', '9843884543', 'B E', 'Php', 'Bangalore', 560045, '2024-01-09 00:00:00', '09-Jan-24', '12:30 PM', 'F9KCRDxh', 1, '1', '2024-01-09 06:44:01'),
(103, 'Bharath', 'bharath21903@gmail.com', '2001-01-09', 'male', 'proton', '7010998968', 'B E', 'Php', 'Bangalore', 560045, '2024-01-09 00:00:00', '09-Jan-24', '12:30 PM', 'rfeBbeti', 2, '1', '2024-01-09 06:54:20'),
(104, 'Bharath Vadde', 'bharathm6604@gmail.com', '2000-01-09', 'male', 'proton', '9000468504', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-09 00:00:00', '09-Jan-24', '12:30 PM', 'pBRHkOOF', 1, '1', '2024-01-09 06:59:22'),
(105, 'Vidyadhari Belagal', 'vidyadharibelagal@gmail.com', '2000-01-05', 'female', 'proton', '8522895695', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-09 00:00:00', '09-Jan-24', '12:30 PM', 'VjgZrCFD', 1, '1', '2024-01-09 06:58:03'),
(108, 'Iyer', 'Iyer@gmail.com', '2023-01-02', 'male', 'proton', '9876543210', 'B.tech', 'asdfas', 'Bangalroe', 560017, '2024-01-10 00:00:00', '10-Jan-24', '05:13 PM', 'zSz3gjCD', 1, '1', '2024-01-10 10:44:30'),
(109, 'chahal', 'Chahal@gmail.com', '2023-01-03', 'male', 'proton', '9876543210', 'B.tech', 'asdfas', 'Bangalroe', 560017, '2024-01-10 00:00:00', '10-Jan-24', '05:19 PM', 'OIpWbqGb', 1, '1', '2024-01-10 10:48:40'),
(110, 'Prasad M J', 'prasadprasad4757@gmail.com', '2000-01-05', 'male', 'proton', '6361588939', 'B E', 'Php', 'Bangalore', 560045, '2024-01-17 00:00:00', '17-Jan-24', '11:00 AM', 'Zb4d6tVc', 1, '1', '2024-01-17 04:41:11'),
(111, 'Lokesha M N', 'lokima2001@gmail.com', '2000-01-12', 'male', 'proton', '9632892013', ' B E', 'Php', 'Bangalore', 560045, '2024-01-17 00:00:00', '17-Jan-24', '11:00 AM', 'vLzTCNwd', 1, '1', '2024-01-17 05:03:31'),
(112, 'Pramoda M G', 'pramodmg85925@gmail.com', '2002-01-17', 'male', 'proton', '7026871920', 'B E', 'Php', 'Bangalore', 560045, '2024-01-17 00:00:00', '17-Jan-24', '11:00 AM', 'JOGnzLjX', 2, '1', '2024-01-17 05:06:36'),
(113, 'Chayan Jain', 'jainchayan2016@gmail.com', '2001-01-17', 'male', 'proton', '9460875975', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-17 00:00:00', '17-Jan-24', '11:00 AM', 'BX7A8Pw2', 1, '1', '2024-01-17 05:17:48'),
(114, 'Mohammed Fardeen', 'mohammedfarr.aslam@gmail.com', '2002-01-17', 'male', 'proton', '6364252056', 'B E', 'Php', 'Bangalore', 560045, '2024-01-17 00:00:00', '17-Jan-24', '11:00 AM', 'iY7n1lck', 1, '1', '2024-01-17 05:14:58'),
(115, 'Kavitha Shantha Kumar', 'kavithashanthakumar1707200@gmail.com', '2002-01-03', 'female', 'proton', '8618912070', 'B E', 'Php', 'Bangalore', 560045, '2024-01-17 00:00:00', '17-Jan-24', '11:00 AM', 'TfC30OOx', 1, '1', '2024-01-17 05:25:41'),
(116, 'Ashitosh K Golabanvi', 'ashitoshgv.09@gmail.com', '2000-01-06', 'male', 'proton', '9341697715', 'B E', 'Php', 'Bangalore', 560045, '2024-01-17 00:00:00', '17-Jan-24', '11:30 AM', 'JXV61Zj6', 1, '1', '2024-01-17 05:42:59'),
(117, 'Sriramula Rajkumar', 'rajkumarsri1437@gmail.com', '1998-01-17', 'male', 'proton', '7075886674', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-17 00:00:00', '17-Jan-24', '03:00 PM', 'R68KDZnG', 1, '1', '2024-01-17 09:13:24'),
(118, 'Ruchitha D N', 'ruchithadn@gmail.com', '2001-01-03', 'female', 'proton', '9353369078', 'B E', 'Php', 'Bangalore', 560045, '2024-01-17 00:00:00', '17-Jan-24', '03:00 PM', 'QF43sgCA', 1, '1', '2024-01-17 09:14:07'),
(119, 'Sachin Gowda', 'sachingowda140302@gmail.com', '2001-01-17', 'male', 'proton', '9686566854', 'B E', 'Php', 'Bangalore', 560045, '2024-01-17 00:00:00', '17-Jan-24', '03:00 PM', 'GTcCFZRP', 1, '1', '2024-01-17 09:18:55'),
(120, 'Mohammed Azeemuddin', 'azeemuddin18122000@gmail.com', '2001-01-17', 'male', 'proton', '9380983890', 'B E', 'Php', 'Bangalore', 560045, '2024-01-17 00:00:00', '17-Jan-24', '04:30 PM', 'Ur7CybDC', 1, '1', '2024-01-17 10:51:22'),
(121, 'Aishwarya M', 'aishwaryam549@gmail.com', '2001-01-18', 'female', 'proton', '7829395168', 'B E', 'Php', 'Bangalore', 560045, '2024-01-18 00:00:00', '18-Jan-24', '11:00 AM', 'cF4m30rE', 1, '1', '2024-01-18 05:04:35'),
(122, 'Betharsi Aravind', 'betharasiaravind@gmail.com', '2001-01-18', 'male', 'proton', '6305898984', 'B E', 'Php', 'Bangalore', 560045, '2024-01-18 00:00:00', '18-Jan-24', '11:00 AM', 'ZxNpTr1q', 1, '1', '2024-01-18 05:26:25'),
(123, 'Amith J', 'amithj885@gmail.com', '2002-01-18', 'male', 'proton', '9110205906', 'B E', 'Php', 'Bangalore', 560045, '2024-01-18 00:00:00', '18-Jan-24', '11:30 AM', 'iKYcODww', 1, '1', '2024-01-18 05:38:14'),
(124, 'Tariq Anwar', 'taiqinterviewslots@gmail.com', '2001-01-03', 'male', 'proton', '9941411888', 'MCA', 'PHP', 'Banglaore', 560045, '2024-01-18 00:00:00', '18-Jan-24', '03:30 PM', 'oAjyWXiR', 1, '1', '2024-01-18 09:35:20'),
(125, 'Reeta Gouda', 'reetasg095@gmail.com', '2002-01-18', 'female', 'proton', '9611903941', 'B E', 'PHP', 'Bangalore', 560045, '2024-01-18 00:00:00', '18-Jan-24', '03:30 PM', 'Hc0seaL9', 1, '1', '2024-01-18 09:35:11'),
(126, 'Shilpa N', 'shilpan2001n@gmail.com', '2002-01-03', 'female', 'proton', '7892773105', 'B Tech', 'PHP', 'Bangalore', 560045, '2024-01-18 00:00:00', '18-Jan-24', '03:30 PM', 'PikKld9f', 1, '1', '2024-01-18 09:40:27'),
(127, 'Anusha S R', 'anusha64sr@gmail.com', '2000-04-06', 'female', 'proton', '7760229729', 'B E', 'Php', 'Bangalore', 560045, '2024-01-23 00:00:00', '23-Jan-24', '03:30 PM', 'bkrpmrOo', 1, '1', '2024-01-23 10:06:34'),
(128, 'Kahnucharan Behera', 'beherakahnucharan95@gmail.com', '2001-01-10', 'male', 'proton', '9556168528', 'MCA', 'Php', 'Bangalore', 560045, '2024-01-23 00:00:00', '23-Jan-24', '03:30 PM', 'l8FbwTUF', 1, '1', '2024-01-23 09:53:20'),
(130, 'Ranjib Mohanty', 'ranjib.mohantyrs@gmail.com', '2001-01-03', 'male', 'proton', '9777824363', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-23 00:00:00', '23-Jan-24', '03:30 PM', 'fkKrUMem', 1, '1', '2024-01-23 09:54:20'),
(131, 'Vinayak R Bellary', 'vinayakballary6@gmail.com', '1998-01-08', 'male', 'proton', '7624941824', 'B E', 'Php', 'Bangalore', 560045, '2024-01-23 00:00:00', '23-Jan-24', '03:30 PM', 'JTZdEm9z', 1, '1', '2024-01-23 09:52:54'),
(132, 'Arshiya Banu', 'arshiyak865@gmail.com', '1999-02-02', 'female', 'proton', '9071308397', 'B E', 'Php', 'Bangalore', 560045, '2024-01-23 00:00:00', '23-Jan-24', '03:30 PM', 'jngSyCHC', 3, '1', '2024-01-23 09:58:25'),
(133, 'RanjithKumar', 'ranjithkumar91001@gmail.com', '2002-01-23', 'male', 'proton', '7893666406', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-23 00:00:00', '23-Jan-24', '03:30 PM', 'BXq1rEHn', 1, '1', '2024-01-23 09:52:58'),
(134, 'Deepak Mahto', 'deepakm766812@gmail.com', '2001-01-04', 'male', 'proton', '8083152662', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-23 00:00:00', '23-Jan-24', '03:35 PM', '1pesnWSj', 1, '1', '2024-01-23 10:01:34'),
(135, 'Iramma', 'irammamadiwal38@gmail.com', '1998-01-07', 'female', 'proton', '7337712129', 'B E', 'Php', 'Bangalore', 560045, '2024-01-24 00:00:00', '24-Jan-24', '03:00 PM', '4oDc11AL', 1, '1', '2024-01-24 09:06:46'),
(136, 'Jayasurya S', 'jayasuryas217@gmail.com', '1999-12-29', 'male', 'proton', '8867808005', 'B E', 'Php', 'Bangalore', 560045, '2024-01-31 00:00:00', '31-Jan-24', '03:00 PM', 'OO44mPtR', 1, '1', '2024-01-31 09:15:59'),
(137, 'Mithil Kanade', 'mithilkanade99@gmail.com', '2000-01-05', 'male', 'proton', '7743935413', 'B E', 'Php', 'Bangalore', 560045, '2024-01-31 00:00:00', '31-Jan-24', '03:00 PM', 'FHglDNum', 1, '1', '2024-01-31 09:15:25'),
(138, 'Geetha Sree', 'geethasreekathi15@gmail.com', '2000-01-06', 'female', 'proton', '9390762965', 'B Tech', 'Php', 'Bangalore', 560045, '2024-01-31 00:00:00', '31-Jan-24', '03:00 PM', 'vAoJ5r1S', 2, '1', '2024-01-31 09:18:17'),
(139, 'Shrinivas Kattimani', 'shreenivaskattimani123@gmail.com', '1998-01-08', 'male', 'proton', '7975352004', 'B E', 'Php', 'Bangalore', 560045, '2024-01-31 00:00:00', '31-Jan-24', '03:00 PM', 'RWNHk2xj', 1, '1', '2024-01-31 09:29:01'),
(140, 'Nandish', 'maramnandish@gmail.com', '2001-10-20', 'male', 'proton', '7337570433', 'B Tech', 'Php', 'Bangalore', 560045, '2024-02-01 00:00:00', '01-Feb-24', '03:30 PM', 'ptLhzRFw', 1, '1', '2024-02-01 09:40:19'),
(141, 'Suprith', 'suprithdharur6@gmail.com', '2002-02-01', 'male', 'proton', '6364270740', 'B E', 'Php', 'Bangalore', 560045, '2024-02-01 00:00:00', '01-Feb-24', '03:30 PM', '9lNkREDU', 1, '1', '2024-02-01 09:39:14'),
(142, 'Pavan Baliga', 'pavanbaliga12@gmail.com', '2002-02-06', 'male', 'proton', '9353240932', 'B E', 'PHP', 'Bangalore', 560045, '2024-02-06 00:00:00', '06-Feb-24', '03:00 PM', '0UP8Da8T', 1, '1', '2024-02-06 09:13:55'),
(143, 'Enugula Pavan Kumar', 'pavankumarenugula777@gmail.com', '2001-02-06', 'male', 'proton', '8106662358', 'B E', 'Php', 'Bangalore', 560045, '2024-02-06 00:00:00', '06-Feb-24', '03:00 PM', 'Ses4CE9N', 1, '1', '2024-02-06 09:20:44'),
(144, 'Praveena H Y', 'praveenhy45@gmail.com', '2001-02-06', 'male', 'proton', '7483446076', 'B E', 'Php', 'Bangalore', 560045, '2024-02-06 00:00:00', '06-Feb-24', '03:30 PM', 'FloAr6cX', 1, '1', '2024-02-06 09:37:08'),
(145, 'R Sagar', 'sagar369gvt@gmail.com', '2001-02-06', 'male', 'proton', '9108798619', 'B E', 'Php', 'Bangalore', 560045, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'vmpXYJOC', 2, '1', '2024-02-14 09:41:02'),
(146, 'Sahana Halappanavar', 'sahanahalappanavar@gmail.com', '2002-02-06', 'female', 'proton', '8088640727', 'B E', 'Php', 'Bangalore', 560045, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'BEXTNlqN', 2, '1', '2024-02-14 09:41:02'),
(184, 'ADITYA ADIGA K', 'adityaadiga.k01@gmail.com', '2002-04-10', 'male', 'Sapthagiri College of Engineering', '9483918989', 'B E', 'CSE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'vF65zFF2', 1, '1', '2024-02-15 05:09:34'),
(185, 'ANSTIN GEORGE', 'anstingeorge01@gmail.com', '1970-01-01', 'male', 'Sapthagiri College of Engineering', '9916952850', 'B E', 'CSE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'L12G9NJN', 1, '1', '2024-02-15 05:07:29'),
(186, 'APOORVA V', 'apoorvavenki8@gmail.com', '1970-01-01', 'female', 'Sapthagiri College of Engineering', '9535447119', 'B E', 'CSE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'FHlQe66C', 1, '1', '2024-02-15 05:12:39'),
(188, 'BADAL KUMAR', 'badalkumarb1998@gmail.com', '1970-01-01', 'male', 'Sapthagiri College of Engineering', '6201617337', 'B E', 'CSE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'cYWn3veQ', 1, '1', '2024-02-15 05:11:40'),
(190, 'GANESHA S', 'ganeshas2003@gmail.com', '1970-01-01', 'male', 'Sapthagiri College of Engineering', '9980774064', 'B E', 'CSE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'agJi0k0K', 1, '1', '2024-02-15 05:06:50'),
(191, 'HARSHITHA J', 'harshithaj3399@gmail.com', '2001-06-02', 'female', 'Sapthagiri College of Engineering', '9535750752', 'B E', 'CSE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'RRiJsudC', 1, '1', '2024-02-15 05:08:44'),
(193, 'KAVYA S', 'kavyasuresh2002@gmail.com', '2002-11-06', 'female', 'Sapthagiri College of Engineering', '9008112755', 'B E', 'CSE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'EuqFvWmv', 1, '1', '2024-02-15 05:09:00'),
(194, 'KHUSHI SHEKHAR T C', 'khushishekhartc@gmail.com', '2003-08-04', 'female', 'Sapthagiri College of Engineering', '9019416540', 'B E', 'CSE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', '1wQ7cF4J', 1, '1', '2024-02-15 05:11:25'),
(197, 'PANCHL MONIKA', 'monikkavpanchal717@gmail.com', '2002-05-08', 'female', 'Sapthagiri College of Engineering', '8867698025', 'B E', 'CSE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'RctGsRJD', 1, '1', '2024-02-15 05:39:36'),
(198, 'RISHAV ANAND', 'rishav0043@gmail.com', '1970-01-01', 'male', 'Sapthagiri College of Engineering', '7763804924', 'B E', 'CSE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'L75fXf4Y', 1, '1', '2024-02-15 05:32:51'),
(199, 'SAKSHEE SINGH', 'saksheesingh59@gmail.com', '1970-01-01', 'female', 'Sapthagiri College of Engineering', '6205470692', 'B E', 'CSE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'myql9hp2', 1, '1', '2024-02-15 05:39:00'),
(200, 'SUKHPREET SINGH', 'ssukhpreet77@gmail.com', '2001-11-11', 'male', 'Sapthagiri College of Engineering', '6284321585', 'B E', 'CSE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'T5x2GpdI', 1, '1', '2024-02-15 05:07:27'),
(201, 'SURYAKANT', 'suryakantha470@gmail.com', '1970-01-01', 'male', 'Sapthagiri College of Engineering', '9110897974', 'B E', 'CSE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'tTtvchid', 1, '1', '2024-02-15 05:08:39'),
(202, 'MANOJ S', 'manojgowda8101@gmail.com', '2001-01-08', 'male', 'Sapthagiri College of Engineering', '9066293341', 'B E', 'CSE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'dTGP8YOh', 1, '1', '2024-02-15 05:15:29'),
(203, 'yashaswini', 'yashuyashaswini59@gmail.com', '2002-03-04', 'female', 'Sapthagiri College of Engineering', '9886276576', 'B E', 'CSE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'RwRwcXYP', 2, '1', '2024-02-15 05:42:57'),
(204, 'Aditya Kumar Gupta', 'adityakr2104@gmail.com', '2000-04-12', 'male', 'Sapthagiri College of Engineering', '9122584350', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'HnurhJNa', 1, '1', '2024-02-15 05:35:20'),
(206, 'Bazgha Dastagir', 'bazghasyed1235@gmail.com', '2002-03-01', 'female', 'Sapthagiri College of Engineering', '6200428287', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'stSKBnLK', 1, '1', '2024-02-15 05:37:17'),
(208, 'Bhishma Narayan pandey', 'bhishmpandey@icloud.com', '2001-04-03', 'male', 'Sapthagiri College of Engineering', '9608006343', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'XgcDUVZ8', 1, '1', '2024-02-15 05:33:01'),
(209, 'Bhoomika B N', 'bhoomikabn23@gmail.com', '2002-07-23', 'female', 'Sapthagiri College of Engineering', '9148852912', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'tJzMvHF5', 1, '1', '2024-02-15 05:38:13'),
(210, 'CHAITHRA S', 'schaithra6360@gmail.com', '2002-12-14', 'female', 'Sapthagiri College of Engineering', '9481869320', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', '9OvziZBa', 1, '1', '2024-02-15 05:11:49'),
(212, 'Devika V Nayak', 'dvnsirsi@gmail.com', '2002-06-26', 'female', 'Sapthagiri College of Engineering', '7411376174', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'G4GQdIFG', 1, '1', '2024-02-15 05:11:16'),
(213, 'Dhanush V.R', 'dhanushvr22@gmail.com', '2002-05-22', 'male', 'Sapthagiri College of Engineering', '8618036674', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'LPhF4SEh', 1, '1', '2024-02-15 05:12:19'),
(214, 'Divya B N', 'divyahegde1892@gmail.com', '2002-10-18', 'female', 'Sapthagiri College of Engineering', '7676993849', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'dLnmgXaf', 1, '1', '2024-02-15 05:36:59'),
(215, 'Hanshika Vijeta', 'hanshikavijeta608@gmail.com', '2001-10-13', 'female', 'Sapthagiri College of Engineering', '9980561386', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'B3veqMBO', 1, '1', '2024-02-15 05:34:01'),
(216, 'Harshith M P', 'harshith.hrithik001@gmail.com', '2002-05-17', 'male', 'Sapthagiri College of Engineering', '7676815517', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'jGcbnZpY', 1, '1', '2024-02-15 05:10:53'),
(218, 'K RAGHU ', 'raghukyrh@gmail.com', '2002-10-07', 'male', 'Sapthagiri College of Engineering', '7975123019', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'rJfRUwSD', 1, '1', '2024-02-15 05:08:37'),
(219, 'Kartik Virupakshappa Rodagai', 'karthikrodagai01@gmail.com', '2001-11-01', 'male', 'Sapthagiri College of Engineering', '9353552925', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'BucyNvUf', 1, '1', '2024-02-15 05:15:20'),
(220, 'Lakshmitha NR ', 'lakshmithaachar17@gmail.com', '2002-03-17', 'female', 'Sapthagiri College of Engineering', '8951084605', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'ERCSrvwZ', 1, '1', '2024-02-15 05:36:13'),
(222, 'Nisha shetty', 'nishakshetty29032003@gmail.com', '2003-03-29', 'female', 'Sapthagiri College of Engineering', '8762133595', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'XztueLfL', 1, '1', '2024-02-15 05:30:19'),
(223, 'Raksha', 'rdevadiga530@gmail.com', '2002-09-23', 'female', 'Sapthagiri College of Engineering', '6362282268', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'zdshxYXf', 1, '1', '2024-02-15 05:29:27'),
(224, 'Shashank M', 'shashankmgowda23@gmail.com', '2003-04-23', 'male', 'Sapthagiri College of Engineering', '9606238730', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'KMdzuQvR', 1, '1', '2024-02-15 05:08:02'),
(229, 'Srushti Basavaraddi', 'srushtibasavaraddi70@gmail.com', '2001-05-15', 'female', 'Sapthagiri College of Engineering', '6361662958', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'wacHeyga', 1, '1', '2024-02-15 05:38:05'),
(230, 'Suhas.S', 'Suhasshiv978@gmail.com', '2002-07-05', 'male', 'Sapthagiri College of Engineering', '9844723435', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'GypD43bm', 1, '1', '2024-02-15 05:06:48'),
(231, 'Utkarsh kumar', 'shrivastwautkarsh005@gmail.com', '2002-08-18', 'male', 'Sapthagiri College of Engineering', '7320829879', 'B E', 'ISE', 'Bangalore', 560057, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'R2Gm6Dxd', 2, '1', '2024-02-15 05:07:14'),
(232, 'Naveen', 'naveen@gmail.com', '2002-02-14', 'male', 'proton', '9874561230', 'B E', 'Php', 'Bangalore', 560045, '2024-02-14 00:00:00', '14-Feb-24', '04:30 PM', 'OVVWUlqb', 2, '1', '2024-02-14 12:04:16'),
(233, 'lavkesh', 'lavkeshprasad@gmail.com', '2024-02-01', 'male', 'Sapthagiri College of Engineering', '8765431234', 'gds', 'fd', 'afds', 876543, '2024-02-15 00:00:00', '15-Feb-24', '03:02 PM', 'V56AtdlQ', 1, '1', '2024-02-15 05:30:10'),
(234, 'jishnu', 'jdjsjime@gmail.com', '2024-02-14', 'male', 'Sapthagiri College of Engineering', '8765431234', 'df', 'ahs', 'g', 876543, '2024-02-15 00:00:00', '15-Feb-24', '03:06 PM', 'e6Upsb83', 1, '1', '2024-02-15 05:38:29'),
(235, 'shreeranksha', 'shreerakshag39@gmail.com', '2024-02-07', 'male', 'Sapthagiri College of Engineering', '8765431234', 'gds', 'sdf', 'fds', 876543, '2024-02-15 00:00:00', '15-Feb-24', '03:15 PM', 'h9A9bXsF', 1, '1', '2024-02-15 05:47:25'),
(236, 'sumukh', 'sumukhkashyap02@gmail.com', '2024-02-14', 'male', 'Sapthagiri College of Engineering', '8765431234', 'gd', 'vsource', 'public_html', 876543, '2024-02-15 00:00:00', '15-Feb-24', '03:18 PM', 'tYf5Bk4Q', 1, '1', '2024-02-15 05:51:00'),
(237, 'devadutta', 'devaduttadevadutta@gmail.com', '2024-02-14', 'male', 'Sapthagiri College of Engineering', '8765431234', 'gds', 'vsource ', 'afds', 876543, '2024-02-15 00:00:00', '15-Feb-24', '02:27 PM', 'GQjeDNXJ', 1, '1', '2024-02-15 05:59:09'),
(239, 'animesh', 'animesdwivedi04@gmail.com', '2024-02-13', 'male', 'Sapthagiri College of Engineering', '9972439037', 'be', 'be', 'bengaluru', 560097, '2024-02-15 00:00:00', '15-Feb-24', '03:37 AM', '2QnWsBZP', 1, '1', '2024-02-15 06:10:17'),
(240, 'Manasa', 'mnsgangadhar@gmail.com', '2000-02-02', 'female', 'Sapthagiri College of Engineering', '8765431234', 'B E', 'PHP', 'Bangalore', 560045, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'Po1DW3l5', 1, '1', '2024-02-15 06:12:27'),
(241, 'smitha', 'smitha2892002@gmail.com', '2024-02-12', 'male', 'Sapthagiri College of Engineering', '9972439037', 'be', 'be', 'bengaluru', 560097, '2024-02-15 00:00:00', '15-Feb-24', '03:41 AM', 'ypu5mb89', 1, '1', '2024-02-15 06:13:03'),
(242, 'sneha', 'snehatina618@gmail.com', '2024-02-12', 'male', 'Sapthagiri College of Engineering', '9972439037', 'be', 'be', 'bengaluru', 560097, '2024-02-15 00:00:00', '15-Feb-24', '03:43 AM', 'fLpssSrg', 1, '1', '2024-02-15 06:19:20'),
(243, 'deeksha', 'deekshas20102@gmail.com', '2024-02-13', 'female', 'Sapthagiri College of Engineering', '9972439037', 'be', 'be', 'bengaluru', 560097, '2024-02-15 00:00:00', '15-Feb-24', '04:46 AM', '1QzKhgFy', 2, '1', '2024-02-15 06:17:28'),
(244, 'Kumudha', 'kumudhahi@gmail.com', '2001-02-01', 'female', 'Sapthagiri College of Engineering', '6360459469', 'B e', 'PHp', 'Bangalore', 560045, '2024-02-15 00:00:00', '15-Feb-24', '12:00 PM', 'M69UBWKP', 1, '1', '2024-02-15 06:18:47'),
(245, 'arpitha', 'arpithamn9148@gmail.com', '2024-02-12', 'female', 'Sapthagiri College of Engineering', '9972439037', 'be', 'be', 'bengaluru', 560097, '2024-02-15 00:00:00', '15-Feb-24', '03:49 AM', 'rRtbu1qg', 1, '1', '2024-02-15 06:20:38'),
(247, 'swetha', 'shwethamngowda17@gmail.com', '2024-02-12', 'female', 'Sapthagiri College of Engineering', '9972439037', 'be', 'be', 'bengaluru', 560097, '2024-02-15 00:00:00', '15-Feb-24', '03:52 AM', 'QumbcrCE', 1, '1', '2024-02-15 06:22:48'),
(248, 'Bharathi', 'bharathigowdad12@gmail.com', '2001-05-30', 'female', 'Sapthagiri College of Engineering', '8088784335', 'B E', 'PHP', 'Bangalore', 560045, '2024-02-15 00:00:00', '15-Feb-24', '01:00 AM', '6ZhumDvU', 1, '1', '2024-02-15 06:42:53'),
(255, 'Savita Puttammanavar', 'sputtammanavar@gmail.com', '1998-09-10', 'female', 'proton', '8746907614', 'MSC', 'MSC', 'Gadag', 582112, '2024-03-11 00:00:00', '11-Mar-24', '01:56 PM', 'HbmjYO7F', 1, '1', '2024-03-11 07:26:42'),
(256, 'test123', 'anjaly.saju@protontech.in', '2024-03-01', 'female', 'abc', '9999999999', 'BE', 'cse', 'dfsfdfd', 888888, '2024-03-13 00:00:00', '13-Mar-24', '05:25 PM', 'dgiUjixL', 2, '1', '2024-03-13 10:16:28'),
(258, 'Dhanush', 'dhanushm1346@gmail.com', '2003-11-13', 'male', 'NBC Degree College', '9746053009', 'BCA', 'Digital Marketing', 'Bangalore', 560077, '2024-05-29 00:00:00', '29-May-24', '10:30 AM', 'O1RXfdSe', 1, '1', '2024-05-29 05:03:59'),
(259, 'Dileep', 'dileep89700@gmail.com', '2000-04-04', 'male', 'NBC Degree College', '8970087377', 'BCA', 'Digital AMarketing', 'Bangalore', 560077, '2024-05-29 00:00:00', '29-May-24', '10:30 AM', 'QXE3Wjfh', 1, '1', '2024-05-29 05:03:21'),
(260, 'Munish', 'munishchandra05@gmail.com', '2002-12-24', 'male', 'NBC Degree College', '9611073914', 'BCA', 'Digital Marketing', 'Bangalore', 560077, '2024-05-29 00:00:00', '29-May-24', '10:30 AM', '7dbxIt6Z', 1, '1', '2024-05-29 05:03:16'),
(262, 'Sagar', 's.gxwda@gmail.com', '2003-01-22', 'male', 'NBC Degree College', '8431107096', 'BCA', 'Digital Marketing', 'Bangalore', 560077, '2024-05-29 00:00:00', '29-May-24', '10:30 AM', 'zEzj8mMu', 1, '1', '2024-05-29 05:02:31'),
(263, 'Aishwarya', 'aishuanu2002@gmail.com', '2002-11-16', 'female', 'NBC Degree College', '8088420485', 'BCA', 'Web Developer', 'Bangalore', 560077, '2024-05-29 00:00:00', '29-May-24', '12:05 PM', 'g9fKDGa2', 1, '1', '2024-05-29 06:40:47'),
(264, 'Sandhya', 'sandhyaharshitha777@gmail.com', '2003-01-22', 'female', 'NBC Degree College', '9901984098', 'BCA', 'Web Developer', 'Bangalore', 560077, '2024-05-29 00:00:00', '29-May-24', '12:05 PM', 'yGx4BHDg', 1, '1', '2024-05-29 06:46:56'),
(265, 'Sanal Babu', 'sanalsabu22@gmail.com', '1999-06-22', 'male', 'NBC Degree College', '8861718806', 'BCA', 'Web Developer', 'Bangalore', 560077, '2024-05-29 00:00:00', '29-May-24', '12:16 PM', 'yJyQ2cbG', 2, '1', '2024-05-29 06:55:34'),
(266, 'Usha', 'ushaspays@gmail.com', '2003-01-08', 'female', 'NBC Degree College', '9035577963', 'BCA', 'Web Developer', 'Bangalore', 560077, '2024-05-29 00:00:00', '29-May-24', '12:14 PM', 'af6CsRjb', 2, '1', '2024-05-29 06:51:48'),
(267, 'Hariprasad ', 'yadavmf49@gmail.com', '2002-10-27', 'male', 'NBC Degree College', '6364067838', 'BCA', 'Digital Marketing', 'Bangalore', 560077, '2024-05-29 00:00:00', '29-May-24', '11:18 AM', 'Y55ph2ZP', 2, '1', '2024-05-29 05:48:27'),
(270, 'test', 'test@gmail.com', '2024-05-29', 'male', 'proton', '9876543128', 'ad', 'a', 'daf', 456787, '2024-05-29 00:00:00', '29-May-24', '06:52 PM', 'RlZcomhM', 1, '1', '2024-05-29 12:22:30'),
(271, 'navi', 'navi@gmail.com', '2024-05-29', 'male', 'proton', '9876543128', 'ad', 'a', 'daf', 456787, '2024-05-29 00:00:00', '29-May-24', '06:58 PM', 'J8bRaA8N', 1, '1', '2024-05-29 12:28:43'),
(274, 'Jayashree', 'jayashree.ranjith@protontech.in', '1987-03-12', 'female', 'proton', '8888888888', 'BTECH', 'Web Development', 'Bangalore', 555555, '2024-06-05 00:00:00', '05-Jun-24', '04:00 PM', 'aOkcUzS5', 1, '1', '2024-06-05 10:35:47'),
(275, 'Anjaly Saju ', 'anjalysaju17@gmail.com', '1998-01-17', 'female', 'proton', '7777777777', 'MBA', 'Web Development', 'Bangalore', 444444, '2024-06-05 00:00:00', '05-Jun-24', '04:00 PM', 'Vn0gL3TO', 1, '1', '2024-06-05 10:30:23'),
(276, 'Naveen Madiwal ', 'naveenmadiwal7777@gmail.com', '2000-12-17', 'male', 'proton', '6666666666', 'BE', 'Web Deveopment', 'Bangalore', 444444, '2024-06-05 00:00:00', '05-Jun-24', '04:00 PM', 'jKBOzBEu', 1, '1', '2024-06-05 10:30:00'),
(277, 'Lokesh V', 'lokeshvijay444@gmail.com', '2002-02-19', 'male', 'proton', '7777777777', 'Bcom', 'Web Development', 'Bangalore', 222222, '2024-06-05 00:00:00', '05-Jun-24', '04:00 PM', 'IpkODH26', 1, '1', '2024-06-05 10:37:34'),
(278, 'Rincy Banu KB ', 'rincybanu663@gmail.com', '1999-04-28', 'female', 'proton', '9888899999', 'BTech', 'Web Development', 'Bangalore', 666666, '2024-06-05 00:00:00', '05-Jun-24', '04:00 PM', 'cnkpdQrm', 1, '1', '2024-06-05 10:30:17'),
(279, 'Hasw', 'aswini@gmail.com', '2000-02-05', 'female', 'proton', '9999999999', 'MBA', 'Web development', 'Bangalore', 666666, '2024-06-05 00:00:00', '05-Jun-24', '04:00 PM', '1rBUlB8T', 1, '1', '2024-06-05 10:33:53');

-- --------------------------------------------------------

--
-- Table structure for table `college_details`
--

CREATE TABLE `college_details` (
  `id` int NOT NULL,
  `name` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `principal_name` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `mobile` varchar(12) COLLATE utf8mb4_general_ci NOT NULL,
  `address` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `location` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `state` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `pincode` varchar(10) COLLATE utf8mb4_general_ci NOT NULL,
  `college_branch` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `details` text COLLATE utf8mb4_general_ci NOT NULL,
  `placement_officer` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `contact_email` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `contact_mobile` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `affiliated_university` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `website` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `approval` enum('pending','approve','reject','blacklist') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `college_details`
--

INSERT INTO `college_details` (`id`, `name`, `principal_name`, `email`, `mobile`, `address`, `location`, `state`, `pincode`, `college_branch`, `details`, `placement_officer`, `contact_email`, `contact_mobile`, `affiliated_university`, `website`, `date`, `approval`) VALUES
(1, 'proton', 'dfghj', 'gfd@gmail.com', '9876543234', 'kujyhtgr', 'asdghj', 'kjhfgdf', '876543', 'kjhgf', 'lkkjh', 'iuy', 'hgd@gmail.com', '9876543123', 'kjhgfdd', 'www.fghjk.com', '2024-02-14 06:19:32', 'approve'),
(6, 'Sapthagiri College of Engineering', 'Dr. H. RAMAKRISHNA', 'principal@sapthagiri.edu.in', '9741341905', '14/5, Hesarghatta Rd, Chikkasandra, MEI Employees Housing Colony, Bengaluru, Karnataka 560057', 'Bangalore', 'Karnataka', '560057', 'VTU', 'hj', 'Suma vishwanath', 'suma@sapthagiri.edu.in', '9741341905', 'Sapthagiri Engineering college is under VTU placed on the list of INDIAS MOST TRUSTED Educational Institutes', 'www.sapthagiri.edu.in', '2024-02-14 09:51:41', 'approve'),
(7, 'fg', 'rd', 'g@gmail.com', '9876542345', 'fd', 'df', 'df', '345676', 'gdgh', 'tgd', 'nh', 'fgh@gmail.com', '9876542345', 'dfgh', 'www.df.com', '2024-02-14 09:36:01', 'approve'),
(8, 'Proton college', 'ra', 'ra@gmail.com', '9874561231', 'HAl', 'Bangalore', 'Karnataka', '560045', 'Bangalore', 'qwdesgdhtgjmh', 'sd', 'sd@gmail.com', '9874563214', 'VTu', 'www.proton.com', '2024-03-01 06:33:20', 'reject'),
(9, 'Proton', 'gf', 'gf@gmail.com', '7894561231', 'Bangalore', 'bangalore', 'Karnataka', '560045', 'bang', 'sdfrgt', 'df', 'df@gmail.com', '9874561231', 'vtu', 'www.vtu.com', '2024-03-01 06:33:20', 'approve'),
(10, 'abc', 'ggbgvb', 'gfg@gmail.com', '9999999999', 'dvfsd', 'cxcvc', 'cxcxv', '656556', 'vvv', 'dsdcf', 'dfggf', 'gfgfgf@gmail.com', '8888888888', 'cbvvb', 'www.example.com', '2024-03-12 09:47:38', 'approve'),
(11, 'NBC Degree College', 'Ms. Jessy Josevini', 'nbccollege@gmail.com', '8951816604', 'Doddagubbi Main Road, Byrathi Post, Kothanur, Bangalore-77.', 'Kothanur', 'Karnataka', '560077', 'Bangalore', 'At NBC College we strive to transform lives and communities by providing equal opportunities through excellence in learning and engagement. Our enthusiasm is to remain competitive and relevant in  the international sense by offering high-quality programs.', 'Ms. Sumaiyah Afreen', 'sumaiyahafreen17136@gmail.com', '9035162382', 'Bangalore North University', 'http://nbccollege.com', '2024-05-28 10:37:21', 'approve');

-- --------------------------------------------------------

--
-- Table structure for table `english_test`
--

CREATE TABLE `english_test` (
  `id` int NOT NULL,
  `question` text COLLATE utf8mb4_general_ci NOT NULL,
  `option_1` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `option_2` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `option_3` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `option_4` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `answer` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `english_test`
--

INSERT INTO `english_test` (`id`, `question`, `option_1`, `option_2`, `option_3`, `option_4`, `answer`) VALUES
(9, 'She ___________ for the company for five years before she got promoted.', 'Works', 'Worked', 'Will work', 'Is working', 'Worked'),
(10, 'Which of the following sentences is in the present perfect tense?', 'I will go to the store later.', 'I went to the store yesterday.', 'I have gone to the store many times.', 'I am going to the store now.', 'I have gone to the store many times.'),
(11, 'Which of the following sentences is in the present continuous tense?', 'They had already finished their dinner when I arrived.', 'I have never seen that movie before.', 'She is singing in the choir at church.', 'He will be visiting his family next week.', 'She is singing in the choir at church.'),
(12, 'Choose the correct adjective to complete the sentence: The ________ puppy wagged its tail happily.', 'shy', 'sad', 'excited', 'angry', 'excited'),
(13, 'Choose the correct adjective to complete the sentence: The ________ mountain peak was covered in snow.', 'rocky', 'steep', 'snowy', 'lush', 'snowy'),
(14, ' ____ English language has become a global language of communication.', 'The', 'A', 'An', 'No article needed', 'The'),
(15, 'She wants to adopt _____ cat from the shelter.', 'the', 'a', 'an', 'no article needed', 'a'),
(16, 'Which of the following is a homophone for “bare”?', 'bear', 'beer', 'both a and b', 'neither a nor b', 'bear'),
(17, 'Which of the following is a homophone for “right”?', 'write', 'wright', 'rite', 'all of the above', 'all of the above'),
(18, ' Which of the following sentences contains a comma splice error?', 'I love to read books, but I don’t have enough time.', 'She studied hard for the test, however, she still failed.', 'The dog barked loudly, and the cat ran away.', 'John went to the store, he bought some milk.', 'She studied hard for the test, however, she still failed.'),
(19, 'Which of the following sentences contains an incorrect use of a pronoun?', 'John and I went to the store to buy some groceries.', 'She told him that she loved him.', 'Whom did you give the keys to?', 'Me and my friends went to the movies last night.', 'Me and my friends went to the movies last night.'),
(20, 'Which of the following sentences is a passive sentence?', 'John painted the house.', 'The book was written by Shakespeare.', 'She sang a song.', 'They built a bridge', 'The book was written by Shakespeare.'),
(21, 'Which of the following sentences is in the future continuous tense?', 'She is cooking dinner right now.', 'I will be studying for the exam tomorrow.', 'They have been working hard all week.', 'The concert was amazing.', 'I will be studying for the exam tomorrow.'),
(22, 'What is the plural of the word “woman”?', 'womens', 'women', 'womanies', 'womanen', 'women'),
(23, 'What is the plural of the word “person”?', 'persons', 'personen', 'people', 'personhood', 'people'),
(24, 'Identify the Abstract Noun in the following sentence: She is so brave that she caught the thief.', 'She', 'Brave', 'Thief', 'Caught', 'Brave'),
(25, 'The CAT drank the MILK from the SAUCER.” – Which kind of nouns are the words in capitals?', 'Common, Uncountable, Common', 'Proper, Common, Common', 'Abstract, Common, Common', 'Common, Compound, Common', 'Common, Uncountable, Common'),
(26, 'What does the prefix “dis-” mean in the word “disagree”?', 'opposite of', 'not', 'more than', 'together', 'not'),
(27, 'What does the prefix “re-” mean in the word “rewrite”?', 'again', 'not', 'opposite of', 'with', 'again'),
(28, 'Which word is odd one out:', 'Radio', 'Television', 'Newspaper', 'Computer', 'Computer'),
(29, 'What is the odd word out of the following:', 'Baseball', 'Soccer', 'Hockey', 'Tennis', 'Tennis'),
(30, 'Which suffix means “pertaining to the stomach”?', '-ectomy', '-algia', '-itis', '-gastric', '-gastric'),
(31, 'Which suffix means “pertaining to the heart”?', '-cardia', '-pnea', '-centesis', '-emia', '-cardia'),
(32, 'Tag Question: He has never been to Europe, ___________?', 'has he?', 'hasn’t he?', 'can he?', 'should he?', 'has he?'),
(33, 'Tag Question: He should study harder, ___________?', 'shouldn’t he?', 'should he?', 'can he?', 'will he?', 'shouldn’t he?'),
(34, 'Tag Question: She’s a good dancer, ___________?', 'isn’t she?', 'is she?', 'can she?', 'will she?', 'isn’t she?'),
(35, 'The birdhouse is hanging ________ the tree.', 'on', 'under', 'beside', 'in', 'on'),
(36, 'An assembly of hearers', 'Audience', 'Crowd', 'Congregation', 'Assemblage', 'Audience'),
(37, 'The fish are swimming ________ the pond.', 'on', 'in', 'beside', 'under', 'in'),
(38, 'Active Voice: \"The dog chased the cat.\"  Change into Passive Voice', 'The cat was chased by the dog.', 'The cat was being chased by the dog.', 'The cat was chased by the dog.', 'The cat had been chased by the dog.', 'The cat was chased by the dog.'),
(39, 'The painting was admired by many people.', 'Many people admired the painting.', 'Many people are admiring the painting.', 'Many people had admired the painting.', 'Many people will admire the painting.', 'Many people admired the painting.'),
(40, 'The novel was written by a famous author.', 'A famous author wrote the novel.', 'A famous author is writing the novel.', 'A famous author had written the novel.', 'A famous author will write the novel.', 'A famous author wrote the novel.'),
(41, 'One who believes in the power of fate:', 'Fatalist', 'Optimist', 'Pessimist', 'Parsimonious', 'Fatalist'),
(42, 'The phone is charging ________ the socket.', 'on', 'under', 'beside', 'in', 'in'),
(43, 'Life history of a person written by another', 'Autobiography', 'Biography', 'Bibliography', 'Memoir', 'Biography'),
(44, 'Change the following sentence into a negative statement: “She always goes to the gym in the morning.”', 'She doesn’t always go to the gym in the morning.', 'She goes to the gym in the morning.', 'She never goes to the gym in the morning.', 'She rarely goes to the gym in the morning.', 'She doesn’t always go to the gym in the morning.'),
(45, 'Change the following sentence into direct speech: “He said that he was tired.”', '“I am tired,” he said.', '“He is tired,” I said.', '“I was tired,” he said.', '“He was tired,” I said.', '“I was tired,” he said.'),
(46, 'Change the following sentence into a positive comparative form: “He is not as tall as his brother.”', 'He is shorter than his brother.', 'He is taller than his brother.', 'He is equally as tall as his brother.', 'He is not tall at all.', 'He is shorter than his brother.'),
(47, 'The weather is warm, _____________ people are still wearing winter coats.', 'because', 'yet', 'and', 'so', 'yet'),
(48, 'The party was great, ___________ there weren’t enough chairs for everyone to sit.', 'but', 'because', 'and', 'so', 'but'),
(49, 'Which of the following is a correct joining sentence for the two sentences below?    “The restaurant was crowded. We had to wait for a table.”', 'Consequently, we decided to try the restaurant next door.', 'Even though it was busy, the food was worth the wait.', 'Furthermore, the waiter was friendly and attentive.', 'On the other hand, the noise level was unbearable.', 'Even though it was busy, the food was worth the wait.'),
(50, 'Which of the following is a correct joining sentence for the two sentences below?    “I love to read. I usually choose mystery novels.”', 'As a result, I have become quite the detective.', 'In addition, I enjoy watching crime dramas on TV.', 'Nevertheless, I occasionally read non-fiction books.', 'On the other hand, I don’t like horror stories at all.', 'Nevertheless, I occasionally read non-fiction books.'),
(51, 'Which of the following is a correct joining sentence for the two sentences below?   “I can’t swim. I’m afraid of the water.”', 'Consequently, I never go to the beach.', 'Even though I like boats, I avoid going out on the water.', 'On the other hand, I enjoy fishing from the shore.', 'Therefore, I’ve never been scuba diving.', 'Consequently, I never go to the beach.'),
(52, 'The ___________ is the largest organ in the body.', 'Liver', 'Skin', 'Heart', 'Brain', 'Skin'),
(53, 'Complete the Sentence: The new system was designed to improve productivity, but it has been met with resistance from the employees. __________.', 'As a result, the company has decided to abandon the project.', 'The management has decided to offer incentives to encourage employees to adapt to the new system.', 'The project was launched without proper communication and training for the employees.', 'The company has decided to continue with the system despite the resistance.', 'The project was launched without proper communication and training for the employees.'),
(54, 'Complete the Sentence:  The movie received mixed reviews from critics, with some praising the acting and others criticizing the storyline. __________.', 'However, the movie was a box office success, earning millions of dollars.', 'As a result, the director has decided to make changes to the storyline for the sequel.', 'The movie was not well received by the audience, leading to poor ticket sales.', 'Despite the criticism, the movie has been nominated for several awards.', 'However, the movie was a box office success, earning millions of dollars.'),
(55, 'Complete the Sentence:   The university has introduced a new course on entrepreneurship. __________.', 'The course has received negative feedback from students and faculty.', 'The course has led to an increase in the number of student startups.', 'The course has been criticized for not being relevant to the students’ majors.', 'The university has faced legal challenges from local businesses for offering the course.', 'The course has led to an increase in the number of student startups.'),
(56, '“Cutting corners” means:', 'To do something in a dishonest or unethical way', 'To take a shortcut to save time or money', 'To be indecisive or unsure about something', 'To ignore something important', 'To take a shortcut to save time or money'),
(57, ' “Get a taste of your own medicine” means:', 'To experience the same negative treatment that you have given to others', 'To learn from one’s mistakes', 'To be rewarded for good behavior', 'To receive an unexpected benefit', 'To experience the same negative treatment that you have given to others'),
(58, '“Hear it on the grapevine” means:', 'To hear a rumor or gossip', 'To receive a formal announcement', 'To experience a surprise or shock', 'To ignore something important', 'To hear a rumor or gossip'),
(59, 'Arrange the following sentences in the correct order:    a. The team won the championship.   b. They celebrated with a parade.   c. The coach praised their hard work.   d. The players lifted the trophy in triumph.', 'c-a-d-b', 'b-a-c-d', 'd-a-c-b', 'a-c-d-b', 'a-c-d-b'),
(60, 'Which is the correct spelling of the word meaning “an ability to do something well”:', 'Talant', 'Tallent', 'Tallet', 'Talent', 'Talent'),
(61, 'Which is the correct spelling of the word meaning “to make something clear or easier to understand”:', 'Clariffy', 'Clarifie', 'Clarify', 'Clarrify', 'Clarify'),
(62, 'Which is the correct spelling of the word meaning “a sudden and severe drop in temperature”:', 'Freez', 'Freze', 'Freeze', 'Frieze', 'Freeze'),
(63, 'Which of the following is a synonym for “Abundance”?', 'Scarcity', 'Surplus', 'Deficiency', 'Shortage', 'Surplus'),
(64, 'Which of the following is a synonym for “Inevitable”?', 'Avoidable', 'Surprising', 'Unlikely', 'Unavoidable', 'Unavoidable'),
(65, 'Which of the following is an antonym of “beginning”?', 'Start', 'End', 'Middle', 'Initiation', 'End'),
(66, 'Which of the following is a homophone for “knight”?', 'night', 'nite', 'both a and b', 'neither a nor b', 'both a and b'),
(67, 'Which of the following sentences is in the present simple tense?', 'He has been working at the company for three years.', 'We are planning a trip to Europe next summer.', 'The train arrives at the station at 9 am every morning.', 'She was singing a song when I walked in.', 'The train arrives at the station at 9 am every morning.'),
(68, 'Which of the following sentences is in the past perfect continuous tense?', 'She has been living in this city for ten years.', 'They had been working on the project for weeks before they finished.', 'He will have been studying for the exam for a week by the time it starts.', 'I am planning to visit my family next month.', 'They had been working on the project for weeks before they finished.'),
(69, 'Active Voice:\"The company hired a new employee.\"  Change into Passive Voice', 'A new employee was hired by the company.', 'A new employee is being hired by the company.', 'A new employee had been hired by the company.', 'A new employee will be hired by the company.', 'A new employee was hired by the company.'),
(70, 'Tag Question: We should leave now, ___________?', 'shouldn’t we?', 'should we?', 'can we?', 'will we?', 'shouldn’t we?'),
(71, 'Which of the following is a correct joining sentence for the two sentences below?   “She is an excellent student. She always gets top grades.”', ' Furthermore, she is very active in extracurricular activities.', 'In fact, she has won several academic awards.', 'Nevertheless, she struggles with public speaking.', 'On the other hand, she excels in math and science.', 'In fact, she has won several academic awards.'),
(72, 'The cookies are ________ the jar.', 'on', 'under', 'beside', 'in', 'in'),
(73, 'The dog is hiding ________ the couch.', 'on', 'under', 'beside', 'in', 'under'),
(74, 'Change the following sentence into a superlative form: “The mountain is tall.”', 'The mountain is tallest.', 'The mountain is more tall.', 'The mountain is most tall.', 'The mountain is taller.', 'The mountain is tallest.'),
(75, 'Which of the following is a synonym for “Hilarious”?', 'Boring', 'Amusing', 'Serious', 'Grim', 'Amusing'),
(76, 'Which is the correct spelling of the word meaning “an event or situation that is beyond your control”:', 'Circumstans', 'Circumstanse', 'Circumstance', 'Circumstansce', 'Circumstance'),
(77, 'Change the following sentence into a conditional sentence: “I will study hard to pass the exam.”', 'If I study hard, I will pass the exam.', 'I studied hard and passed the exam.', 'I passed the exam without studying.', 'I won’t study hard, but I’ll still pass the exam.', 'If I study hard, I will pass the exam.'),
(78, 'Passive Voice: \"The cake was baked by Sarah.\"  Change into Active Voice', ' Sarah baked the cake.', ' Sarah is baking the cake.', ' Sarah had baked the cake.', ' Sarah will bake the cake.', ' Sarah baked the cake.'),
(79, 'Passive Voice: \"The movie was watched by me last night.\"   Change into Active Voice', ' I watched the movie last night..', ' I am watching the movie right now.', ' I will watch the movie tonight.', ' I have watched the movie before.', ' I watched the movie last night.');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Id` int NOT NULL,
  `username` text NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Id`, `username`, `password`) VALUES
(1, 'admin', '5*&12$#Tr=');

-- --------------------------------------------------------

--
-- Table structure for table `performance`
--

CREATE TABLE `performance` (
  `id` int NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `english` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `aptitude` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `technical` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `total` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `answered` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `unanswered` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `test_status` enum('pass','fail') COLLATE utf8mb4_general_ci NOT NULL,
  `remark` enum('-','select','non-select') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `time_stamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `performance`
--

INSERT INTO `performance` (`id`, `name`, `email`, `english`, `aptitude`, `technical`, `total`, `answered`, `unanswered`, `test_status`, `remark`, `status`, `time_stamp`) VALUES
(4, 'Mohan', 'mohanreddym796@gmail.com', '7', '7', '4', '18', '60', '0', 'fail', 'non-select', '', '2023-12-19 08:11:47'),
(7, 'Dinesh', 'dineshkarthivel@gmail.com', '9', '3', '2', '14', '60', '0', 'fail', 'select', '', '2023-12-19 08:06:09'),
(9, 'Goutameshwar', 'gauthamcharodi23@gmail.com', '11', '5', '10', '26', '60', '0', 'fail', 'select', '', '2023-12-20 06:21:18'),
(10, 'Nitish', 'nitishmani1111@gmail.com', '15', '7', '7', '29', '60', '0', 'fail', 'select', '', '2023-12-20 06:36:03'),
(12, 'Saba', 'afreensaba97@gmail.com', '10', '3', '9', '22', '60', '0', 'fail', 'select', '', '2023-12-20 07:51:01'),
(14, 'Pavithra', 'pavithrabs2000@gmail.com', '7', '2', '1', '10', '60', '0', 'fail', 'select', '', '2023-12-21 06:46:15'),
(15, 'Deepa', 'deepask253@gmail.com', '9', '2', '4', '15', '60', '0', 'fail', 'select', '', '2023-12-21 06:46:58'),
(21, 'Kaushal', 'shivaramkaushal@gmail.com', '11', '1', '4', '16', '60', '0', 'fail', 'select', '', '2023-12-22 05:44:01'),
(25, 'Syed', 'syed567syed@gmail.com', '15', '2', '7', '24', '60', '0', 'fail', '-', '', '2023-12-26 06:45:18'),
(27, 'S', 'poomaniselvam518@gmail.com', '10', '4', '5', '19', '60', '0', 'fail', '-', '', '2023-12-26 06:56:41'),
(34, 'Darshan', 'naikdarshan547@gmail.com', '9', '1', '1', '11', '57', '3', 'fail', '-', '', '2023-12-27 06:37:47'),
(36, 'pant', 'pan@outlook.com', '5', '2', '0', '7', '24', '36', 'fail', '-', '', '2023-12-28 07:33:15'),
(37, 'Mahammad', 'mahammadrafi1506@gmail.com', '15', '7', '8', '30', '60', '0', 'fail', 'select', '', '2023-12-29 05:56:37'),
(38, 'Srivatsa', 'Srivathsa901@gmail.com', '13', '3', '4', '20', '60', '0', 'fail', '-', '', '2023-12-29 06:19:29'),
(40, 'Ganesha', 'ganeshashet24@gmail.com', '13', '2', '7', '22', '60', '0', 'fail', '-', '', '2023-12-29 06:21:54'),
(44, 'Abhishek', 'yabhishekabi1@gmail.com', '8', '3', '8', '19', '60', '0', 'pass', '-', '', '2024-01-02 05:57:06'),
(45, 'Sandhya', 'sandhyakoudi7@gmail.com', '14', '2', '9', '25', '60', '0', 'pass', '-', '', '2024-01-02 06:16:13'),
(46, 'Tejas', 'tejasvijendra@gmail.com', '11', '2', '10', '23', '60', '0', 'pass', '-', '', '2024-01-02 06:51:13'),
(47, 'Shanmukha', 'shanmukhakuner@gmail.com', '8', '3', '7', '18', '60', '0', 'fail', '-', '', '2024-01-02 07:00:30'),
(48, 'Jeevan', 'jeevanofficial@gmail.com', '13', '1', '6', '20', '60', '0', 'pass', '-', '', '2024-01-02 07:15:22'),
(51, 'Vivekananda', 'vivekgowda997@gmail.com', '7', '3', '2', '12', '60', '0', 'fail', '-', '', '2024-01-03 06:03:56'),
(52, 'Hema', 'gsh62388@gmail.com', '8', '3', '2', '13', '60', '0', 'fail', '-', '', '2024-01-03 06:20:19'),
(53, 'Vaishnavi', 'vaishnavianegundi393@gmail.com', '12', '1', '6', '19', '60', '0', 'fail', '-', '', '2024-01-03 06:29:03'),
(54, 'Jeevan', 'jeevanjai55@gmail.com', '10', '2', '8', '20', '60', '0', 'fail', '-', '', '2024-01-03 06:38:32'),
(59, 'Mallikarjuna', 'hokranimallikarjuna@gmail.com', '11', '3', '8', '22', '60', '0', 'fail', '-', '', '2024-01-04 05:57:13'),
(60, 'Harikrishna', 'harikrishna32031@gmail.com', '15', '5', '7', '27', '60', '0', 'fail', '-', '', '2024-01-04 06:01:12'),
(61, 'Rajyalakshmi', 'mekalarajyalakshmi55@gmail.com', '13', '5', '10', '28', '60', '0', 'fail', '-', '', '2024-01-04 06:12:35'),
(63, 'Jayanth', 'jayanthnkallahalli@gmail.com', '16', '1', '10', '27', '60', '0', 'fail', '-', '', '2024-01-04 06:15:23'),
(64, 'Sree', 'sakeharshitha678@gmail.com', '10', '4', '13', '27', '60', '0', 'fail', '-', '', '2024-01-04 06:15:28'),
(65, 'Bhavya', 'bhavyakrish2001@gmail.com', '15', '1', '11', '27', '60', '0', 'fail', '-', '', '2024-01-04 06:33:35'),
(66, 'Boomika', 'boomikap335@gmail.com', '9', '3', '11', '23', '60', '0', 'fail', '-', '', '2024-01-04 07:02:28'),
(67, 'Hanumateja', 'hanumatheja382@gmail.com', '9', '4', '4', '17', '60', '0', 'fail', '-', '', '2024-01-04 07:07:55'),
(68, 'Chandrakanti', 'chandrakantimalik11@gmail.com', '16', '8', '12', '36', '60', '0', 'pass', 'select', '', '2024-01-04 07:28:27'),
(69, 'Hrushikesh', 'hrushikeshpradhan055@gmail.com', '11', '4', '9', '24', '60', '0', 'fail', '-', '', '2024-01-04 07:09:43'),
(70, 'Ashwini', 'chottuu7274@gmail.com', '10', '1', '13', '24', '60', '0', 'fail', '-', '', '2024-01-04 07:19:42'),
(71, 'Anuragh', 'anurag.kadri@gmail.com', '15', '5', '16', '36', '60', '0', 'pass', 'select', '', '2024-01-04 07:28:25'),
(72, 'Karthik', 'dskarthi2706@gmail.com', '10', '5', '13', '28', '60', '0', 'fail', '-', '', '2024-01-04 10:08:08'),
(73, 'Navyashree', 'klnavya2000@gmail.com', '7', '3', '11', '21', '60', '0', 'fail', '-', '', '2024-01-04 10:09:20'),
(74, 'Sahana', 'sahanbmahadevappa@gmail.com', '11', '1', '8', '20', '60', '0', 'fail', '-', '', '2024-01-04 10:16:22'),
(75, 'Madhavi', 'madhusamanuri7@gmail.com', '12', '3', '10', '25', '60', '0', 'fail', '-', '', '2024-01-04 10:27:53'),
(76, 'Haritha', 'nagishettyharitha304@gmail.com', '13', '5', '14', '32', '60', '0', 'pass', 'select', '', '2024-01-04 11:07:20'),
(77, 'Pavan', 'ppk152000@gmail.com', '5', '2', '6', '13', '60', '0', 'fail', '-', '', '2024-01-04 10:29:13'),
(78, 'Logeshwaran', 'logeshw748@gmail.com', '12', '9', '15', '36', '60', '0', 'pass', 'select', '', '2024-01-04 11:07:15'),
(79, 'Nithyashree', 'nithyahrees2242000@gmail.com', '8', '2', '12', '22', '60', '0', 'fail', '-', '', '2024-01-04 10:38:28'),
(80, 'Sandhya', 'sandhyarb351@gmail.com', '13', '3', '11', '27', '60', '0', 'fail', '-', '', '2024-01-05 05:55:36'),
(81, 'Vijetha', 'vijethasmeti1092@gmail.com', '11', '1', '9', '21', '60', '0', 'fail', '-', '', '2024-01-05 06:03:24'),
(82, 'Sharath', 'arsharath02@gmail.com', '10', '2', '11', '23', '60', '0', 'fail', '-', '', '2024-01-05 06:04:33'),
(83, 'K', 'kamulurisafiya@gmail.com', '9', '1', '12', '22', '60', '0', 'fail', '-', '', '2024-01-05 06:07:58'),
(84, 'Vidya', 'vidyasm54@gmail.com', '14', '2', '8', '24', '60', '0', 'fail', '-', '', '2024-01-05 06:08:22'),
(85, 'Ameen', 'ameenulrooh98@gmail.com', '8', '2', '8', '18', '60', '0', 'fail', '-', '', '2024-01-05 06:54:39'),
(88, 'ARUNRAJ', 'antonyarunraj@gmail.com', '11', '5', '11', '27', '60', '0', 'fail', '-', '', '2024-01-09 05:33:19'),
(90, 'Sasikumar', 'thurakasasikumar507@gmail.com', '10', '5', '10', '25', '60', '0', 'fail', '-', '', '2024-01-09 06:42:11'),
(91, 'Achyuth', 'achyuthadabala@gmail.com', '11', '5', '7', '23', '60', '0', 'fail', '-', '', '2024-01-09 06:49:12'),
(92, 'Laxmikanth', 'laxmikanthpatil7777@gmail.com', '13', '3', '11', '27', '56', '4', 'fail', '-', '', '2024-01-09 06:54:34'),
(93, 'Rishabh', 'kingrishabh16@gmail.com', '17', '4', '13', '34', '60', '0', 'pass', '-', '', '2024-01-09 06:55:26'),
(94, 'Srinivasa', 'elakotisrinu48@gmail.com', '15', '2', '9', '26', '57', '3', 'fail', '-', '', '2024-01-09 07:05:20'),
(95, 'Rajshekhar', 'mrajasekhar9676@gmail.com', '11', '6', '11', '28', '60', '0', 'fail', '-', '', '2024-01-09 07:06:31'),
(96, 'Indra', 'indrasena197@gmail.com', '14', '4', '10', '28', '60', '0', 'fail', '-', '', '2024-01-09 07:06:58'),
(97, 'Venkata', 'venkatasurendra70@gmail.com', '11', '3', '14', '28', '60', '0', 'fail', '-', '', '2024-01-09 07:23:50'),
(98, 'Sreekanth', 'sreekanth.t053@gmail.com', '5', '3', '8', '16', '60', '0', 'fail', '-', '', '2024-01-09 07:31:34'),
(99, 'Bharath', 'bharath21903@gmail.com', '16', '3', '14', '33', '60', '0', 'pass', '-', '', '2024-01-09 07:42:18'),
(100, 'Aarthi', 'aarthi2000cse@gmail.com', '10', '3', '13', '26', '60', '0', 'fail', '-', '', '2024-01-09 07:44:05'),
(101, 'Vidyadhari', 'vidyadharibelagal@gmail.com', '15', '7', '17', '39', '60', '0', 'pass', '-', '', '2024-01-09 07:56:16'),
(102, 'Bharath', 'bharathm6604@gmail.com', '11', '3', '12', '26', '60', '0', 'fail', '-', '', '2024-01-09 07:59:12'),
(103, 'Prasad', 'prasadprasad4757@gmail.com', '10', '4', '15', '29', '60', '0', 'fail', 'select', '', '2024-01-18 05:58:14'),
(104, 'Lokesha', 'lokima2001@gmail.com', '13', '4', '5', '22', '60', '0', 'fail', '-', '', '2024-01-17 05:50:30'),
(105, 'Mohammed', 'mohammedfarr.aslam@gmail.com', '9', '2', '11', '22', '60', '0', 'fail', '-', '', '2024-01-17 05:54:09'),
(106, 'Pramoda', 'pramodmg85925@gmail.com', '5', '2', '8', '15', '60', '0', 'fail', '-', '', '2024-01-17 06:00:51'),
(107, 'Chayan', 'jainchayan2016@gmail.com', '9', '8', '9', '26', '60', '0', 'fail', '-', '', '2024-01-17 06:20:45'),
(108, 'Kavitha', 'kavithashanthakumar1707200@gmail.com', '12', '3', '8', '23', '60', '0', 'fail', '-', '', '2024-01-17 06:23:22'),
(109, 'Ashitosh', 'ashitoshgv.09@gmail.com', '8', '4', '5', '17', '60', '0', 'fail', '-', '', '2024-01-17 06:31:14'),
(110, 'Sachin', 'sachingowda140302@gmail.com', '10', '2', '16', '28', '60', '0', 'fail', 'select', '', '2024-01-18 06:02:21'),
(111, 'Ruchitha', 'ruchithadn@gmail.com', '8', '1', '7', '16', '60', '0', 'fail', '-', '', '2024-01-17 10:09:28'),
(112, 'Sriramula', 'rajkumarsri1437@gmail.com', '11', '1', '8', '20', '60', '0', 'fail', '-', '', '2024-01-17 10:13:38'),
(113, 'Mohammed', 'azeemuddin18122000@gmail.com', '11', '1', '7', '19', '60', '0', 'fail', '-', '', '2024-01-17 11:33:09'),
(114, 'Aishwarya', 'aishwaryam549@gmail.com', '10', '2', '6', '18', '60', '0', 'fail', '-', '', '2024-01-18 06:04:54'),
(115, 'Amith', 'amithj885@gmail.com', '10', '5', '6', '21', '60', '0', 'fail', '-', '', '2024-01-18 06:14:51'),
(116, 'Betharsi', 'betharasiaravind@gmail.com', '10', '5', '8', '23', '60', '0', 'fail', '-', '', '2024-01-18 06:25:58'),
(117, 'Shilpa', 'shilpan2001n@gmail.com', '11', '4', '9', '24', '60', '0', 'fail', '-', '', '2024-01-18 10:18:03'),
(118, 'Tariq', 'taiqinterviewslots@gmail.com', '12', '0', '9', '21', '60', '0', 'fail', '-', '', '2024-01-18 10:24:15'),
(119, 'Reeta', 'reetasg095@gmail.com', '11', '6', '10', '27', '60', '0', 'fail', '-', '', '2024-01-18 10:33:02'),
(120, 'RanjithKumar', 'ranjithkumar91001@gmail.com', '16', '6', '11', '33', '60', '0', 'pass', 'select', '', '2024-01-23 11:27:58'),
(121, 'Anusha', 'anusha64sr@gmail.com', '10', '3', '3', '16', '60', '0', 'fail', '-', '', '2024-01-23 10:50:42'),
(122, 'Vinayak', 'vinayakballary6@gmail.com', '7', '7', '3', '17', '49', '11', 'fail', '-', '', '2024-01-23 10:53:33'),
(123, 'Ranjib', 'ranjib.mohantyrs@gmail.com', '13', '3', '6', '22', '60', '0', 'fail', '-', '', '2024-01-23 10:54:07'),
(124, 'Deepak', 'deepakm766812@gmail.com', '14', '2', '13', '29', '60', '0', 'fail', 'select', '', '2024-01-23 11:27:51'),
(125, 'Kahnucharan', 'beherakahnucharan95@gmail.com', '10', '4', '7', '21', '53', '7', 'fail', '-', '', '2024-01-23 10:54:54'),
(126, 'Arshiya', 'arshiyak865@gmail.com', '10', '1', '6', '17', '60', '0', 'fail', '-', '', '2024-01-23 10:57:06'),
(127, 'Iramma', 'irammamadiwal38@gmail.com', '8', '1', '9', '18', '60', '0', 'fail', '-', '', '2024-01-24 10:05:09'),
(128, 'Geetha', 'geethasreekathi15@gmail.com', '15', '5', '9', '29', '60', '0', 'fail', '-', '', '2024-01-31 09:42:07'),
(129, 'Mithil', 'mithilkanade99@gmail.com', '8', '1', '3', '12', '60', '0', 'fail', '-', '', '2024-01-31 09:45:27'),
(130, 'Jayasurya', 'jayasuryas217@gmail.com', '8', '3', '6', '17', '60', '0', 'fail', '-', '', '2024-01-31 09:57:26'),
(131, 'Shrinivas', 'shreenivaskattimani123@gmail.com', '9', '4', '4', '17', '60', '0', 'fail', '-', '', '2024-01-31 10:07:22'),
(132, 'Suprith', 'suprithdharur6@gmail.com', '13', '7', '6', '26', '60', '0', 'fail', '-', '', '2024-02-01 10:39:20'),
(133, 'Nandish', 'maramnandish@gmail.com', '11', '4', '5', '20', '60', '0', 'fail', '-', '', '2024-02-01 10:40:02'),
(134, 'Pavan', 'pavanbaliga12@gmail.com', '5', '2', '5', '12', '60', '0', 'fail', '-', '', '2024-02-06 09:46:26'),
(135, 'Praveena', 'praveenhy45@gmail.com', '11', '4', '8', '23', '60', '0', 'fail', '-', '', '2024-02-06 10:08:38'),
(136, 'R', 'sagar369gvt@gmail.com', '10', '2', '7', '19', '60', '0', 'fail', '-', '', '2024-02-06 10:18:37'),
(137, 'Enugula', 'pavankumarenugula777@gmail.com', '14', '3', '7', '24', '60', '0', 'fail', '-', '', '2024-02-06 10:21:19'),
(138, 'Sahana', 'sahanahalappanavar@gmail.com', '14', '6', '11', '31', '60', '0', 'pass', '-', '', '2024-02-06 10:24:47'),
(140, 'ADITYA', 'adityaadiga.k01@gmail.com', '14', '2', '10', '26', '57', '3', 'fail', '-', '', '2024-02-15 05:43:50'),
(141, 'BADAL', 'badalkumarb1998@gmail.com', '9', '2', '9', '20', '60', '0', 'fail', '-', '', '2024-02-15 05:50:32'),
(143, 'Utkarsh', 'shrivastwautkarsh005@gmail.com', '13', '4', '15', '32', '60', '0', 'pass', '-', '', '2024-02-15 05:52:10'),
(144, 'GANESHA', 'ganeshas2003@gmail.com', '15', '0', '1', '16', '33', '27', 'fail', '-', '', '2024-02-15 05:58:49'),
(145, 'ANSTIN', 'anstingeorge01@gmail.com', '6', '5', '1', '12', '36', '24', 'fail', '-', '', '2024-02-15 05:59:59'),
(146, 'SUKHPREET', 'ssukhpreet77@gmail.com', '6', '1', '1', '8', '30', '30', 'fail', '-', '', '2024-02-15 06:00:12'),
(147, 'K', 'raghukyrh@gmail.com', '17', '2', '12', '31', '60', '0', 'pass', '-', '', '2024-02-15 06:02:16'),
(148, 'Aditya', 'adityakr2104@gmail.com', '2', '0', '1', '3', '24', '36', 'fail', '-', '', '2024-02-15 06:02:45'),
(149, 'Bhishma', 'bhishmpandey@icloud.com', '8', '0', '5', '13', '42', '18', 'fail', '-', '', '2024-02-15 06:04:17'),
(150, 'Suhas.S', 'Suhasshiv978@gmail.com', '16', '4', '15', '35', '60', '0', 'pass', '-', '', '2024-02-15 06:04:22'),
(151, 'RISHAV', 'rishav0043@gmail.com', '2', '0', '0', '2', '11', '49', 'fail', '-', '', '2024-02-15 06:05:04'),
(152, 'Raksha', 'rdevadiga530@gmail.com', '14', '2', '9', '25', '60', '0', 'fail', '-', '', '2024-02-15 06:05:21'),
(153, 'MANOJ', 'manojgowda8101@gmail.com', '13', '4', '10', '27', '60', '0', 'fail', '-', '', '2024-02-15 06:06:02'),
(154, 'SURYAKANT', 'suryakantha470@gmail.com', '12', '4', '7', '23', '60', '0', 'fail', '-', '', '2024-02-15 06:06:08'),
(155, 'CHAITHRA', 'schaithra6360@gmail.com', '4', '0', '11', '15', '57', '3', 'fail', '-', '', '2024-02-15 06:06:38'),
(156, 'Hanshika', 'hanshikavijeta608@gmail.com', '14', '0', '11', '25', '60', '0', 'fail', '-', '', '2024-02-15 06:07:12'),
(157, 'Harshith', 'harshith.hrithik001@gmail.com', '18', '4', '11', '33', '56', '4', 'pass', '-', '', '2024-02-15 06:07:32'),
(158, 'APOORVA', 'apoorvavenki8@gmail.com', '13', '3', '16', '32', '60', '0', 'pass', '-', '', '2024-02-15 06:08:35'),
(159, 'KHUSHI', 'khushishekhartc@gmail.com', '10', '2', '12', '24', '60', '0', 'fail', '-', '', '2024-02-15 06:08:36'),
(160, 'Kartik', 'karthikrodagai01@gmail.com', '7', '3', '9', '19', '60', '0', 'fail', '-', '', '2024-02-15 06:10:26'),
(161, 'Devika', 'dvnsirsi@gmail.com', '12', '2', '10', '24', '60', '0', 'fail', '-', '', '2024-02-15 06:10:50'),
(162, 'Bhoomika', 'bhoomikabn23@gmail.com', '0', '0', '5', '5', '38', '22', 'fail', '-', '', '2024-02-15 06:10:53'),
(163, 'Divya', 'divyahegde1892@gmail.com', '1', '0', '0', '1', '24', '36', 'fail', '-', '', '2024-02-15 06:11:04'),
(164, 'HARSHITHA', 'harshithaj3399@gmail.com', '16', '4', '14', '34', '60', '0', 'pass', '-', '', '2024-02-15 06:11:48'),
(165, 'Shashank', 'shashankmgowda23@gmail.com', '15', '5', '7', '27', '53', '7', 'fail', '-', '', '2024-02-15 06:12:30'),
(166, 'Dhanush', 'dhanushvr22@gmail.com', '11', '5', '10', '26', '60', '0', 'fail', '-', '', '2024-02-15 06:12:57'),
(167, 'Srushti', 'srushtibasavaraddi70@gmail.com', '0', '1', '0', '1', '16', '44', 'fail', '-', '', '2024-02-15 06:13:27'),
(168, 'PANCHL', 'monikkavpanchal717@gmail.com', '0', '1', '8', '9', '50', '10', 'fail', '-', '', '2024-02-15 06:13:28'),
(169, 'SAKSHEE', 'saksheesingh59@gmail.com', '0', '0', '3', '3', '52', '8', 'fail', '-', '', '2024-02-15 06:13:37'),
(170, 'KAVYA', 'kavyasuresh2002@gmail.com', '14', '2', '13', '29', '60', '0', 'fail', '-', '', '2024-02-15 06:14:00'),
(171, 'lavkesh', 'lavkeshprasad@gmail.com', '14', '1', '8', '23', '60', '0', 'fail', '-', '', '2024-02-15 06:14:11'),
(172, 'yashaswini', 'yashuyashaswini59@gmail.com', '9', '3', '5', '17', '60', '0', 'fail', '-', '', '2024-02-15 06:15:37'),
(173, 'Lakshmitha', 'lakshmithaachar17@gmail.com', '4', '1', '6', '11', '60', '0', 'fail', '-', '', '2024-02-15 06:17:32'),
(174, 'Nisha', 'nishakshetty29032003@gmail.com', '16', '5', '12', '33', '60', '0', 'pass', 'select', '', '2024-03-01 06:42:41'),
(175, 'sumukh', 'sumukhkashyap02@gmail.com', '2', '1', '1', '4', '33', '27', 'fail', '-', '', '2024-02-15 06:18:02'),
(176, 'Bazgha', 'bazghasyed1235@gmail.com', '1', '0', '0', '1', '19', '41', 'fail', '-', '', '2024-02-15 06:18:21'),
(177, 'animesh', 'animesdwivedi04@gmail.com', '0', '0', '0', '0', '16', '44', 'fail', '-', '', '2024-02-15 06:21:00'),
(178, 'jishnu', 'jdjsjime@gmail.com', '7', '4', '4', '15', '38', '22', 'fail', '-', '', '2024-02-15 06:22:55'),
(179, 'shreeranksha', 'shreerakshag39@gmail.com', '16', '3', '11', '30', '60', '0', 'fail', 'select', '', '2024-03-01 06:42:02'),
(180, 'devadutta', 'devaduttadevadutta@gmail.com', '14', '4', '11', '29', '60', '0', 'fail', '-', '', '2024-02-15 06:31:07'),
(181, 'Kumudha', 'kumudhahi@gmail.com', '10', '3', '9', '22', '60', '0', 'fail', '-', '', '2024-02-15 06:40:20'),
(182, 'deeksha', 'deekshas20102@gmail.com', '10', '4', '10', '24', '60', '0', 'fail', '-', '', '2024-02-15 06:45:33'),
(183, 'smitha', 'smitha2892002@gmail.com', '14', '2', '9', '25', '60', '0', 'fail', '-', '', '2024-02-15 06:45:45'),
(184, 'swetha', 'shwethamngowda17@gmail.com', '9', '2', '13', '24', '60', '0', 'fail', '-', '', '2024-02-15 06:46:11'),
(185, 'sneha', 'snehatina618@gmail.com', '16', '2', '6', '24', '60', '0', 'fail', '-', '', '2024-02-15 06:46:49'),
(186, 'arpitha', 'arpithamn9148@gmail.com', '8', '3', '11', '22', '60', '0', 'fail', '-', '', '2024-02-15 06:49:03'),
(187, 'Manasa', 'mnsgangadhar@gmail.com', '14', '5', '8', '27', '60', '0', 'fail', '-', '', '2024-02-15 06:57:24'),
(188, 'Bharathi', 'bharathigowdad12@gmail.com', '10', '1', '10', '21', '60', '0', 'fail', '-', '', '2024-02-15 07:18:15'),
(190, 'Savita Puttammanavar', 'sputtammanavar@gmail.com', '0', '0', '20', '20', '60', '0', 'fail', 'select', '', '2024-03-12 10:31:52'),
(191, 'test123', 'anjaly.saju@protontech.in', '0', '0', '0', '0', '0', '60', 'fail', '-', '', '2024-03-13 10:19:42'),
(192, 'Dileep', 'dileep89700@gmail.com', '8', '0', '18', '26', '50', '0', 'fail', '-', '', '2024-05-29 05:30:07'),
(193, 'Sagar', 's.gxwda@gmail.com', '8', '0', '17', '25', '50', '0', 'fail', '-', '', '2024-05-29 05:40:45'),
(194, 'Munish', 'munishchandra05@gmail.com', '6', '0', '14', '20', '50', '0', 'fail', '-', '', '2024-05-29 05:56:47'),
(195, 'Hariprasad', 'yadavmf49@gmail.com', '7', '0', '15', '22', '50', '0', 'fail', '-', '', '2024-05-29 06:00:27'),
(196, 'Dhanush', 'dhanushm1346@gmail.com', '10', '0', '17', '27', '50', '0', 'fail', '-', '', '2024-05-29 06:04:06'),
(197, 'Aishwarya', 'aishuanu2002@gmail.com', '8', '0', '12', '20', '50', '0', 'fail', '-', '', '2024-05-29 07:35:00'),
(198, 'Usha', 'ushaspays@gmail.com', '10', '0', '13', '23', '50', '0', 'fail', '-', '', '2024-05-29 07:49:04'),
(199, 'Sandhya', 'sandhyaharshitha777@gmail.com', '7', '0', '14', '21', '50', '0', 'fail', '-', '', '2024-05-29 07:56:04'),
(200, 'Sanal', 'sanalsabu22@gmail.com', '10', '0', '14', '24', '49', '1', 'fail', '-', '', '2024-05-29 07:59:02'),
(202, 'Anjaly', 'anjalysaju17@gmail.com', '0', '0', '17', '17', '70', '0', 'fail', '-', '', '2024-06-05 10:34:03'),
(203, 'Rincy', 'rincybanu663@gmail.com', '0', '0', '17', '17', '70', '0', 'fail', '-', '', '2024-06-05 10:38:28'),
(204, 'Naveen', 'naveenmadiwal7777@gmail.com', '0', '0', '22', '22', '70', '0', 'fail', '-', '', '2024-06-05 10:42:24'),
(205, 'Hasw', 'aswini@gmail.com', '0', '0', '11', '11', '70', '0', 'fail', '-', '', '2024-06-05 10:42:40'),
(206, 'Lokesh', 'lokeshvijay444@gmail.com', '0', '0', '18', '18', '70', '0', 'fail', '-', '', '2024-06-05 10:43:36'),
(207, 'Jayashree', 'jayashree.ranjith@protontech.in', '0', '0', '5', '5', '43', '27', 'fail', '-', '', '2024-06-05 11:36:54');

-- --------------------------------------------------------

--
-- Table structure for table `program_test`
--

CREATE TABLE `program_test` (
  `id` int NOT NULL,
  `question` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `option_1` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `option_2` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `option_3` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `option_4` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `answer` varchar(500) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `question_pattern`
--

CREATE TABLE `question_pattern` (
  `id` int NOT NULL,
  `dot` varchar(100) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `aptitude` int NOT NULL,
  `english` int NOT NULL,
  `technical` int NOT NULL,
  `type` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `average` int NOT NULL,
  `hour` int NOT NULL,
  `minute` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `question_pattern`
--

INSERT INTO `question_pattern` (`id`, `dot`, `aptitude`, `english`, `technical`, `type`, `average`, `hour`, `minute`) VALUES
(1, '30-December-2021 	', 1, 1, 1, 'Web Developer', 50, 1, 1),
(3, NULL, 2, 2, 2, 'Web Developer', 70, 1, 1),
(4, NULL, 3, 3, 3, 'Web Developer', 60, 1, 1),
(5, NULL, 6, 4, 30, 'Web Developer', 50, 1, 0),
(6, NULL, 6, 4, 30, 'Web Developer', 50, 1, 0),
(7, '18-Dec-23', 10, 20, 30, 'Web Developer', 50, 1, 0),
(8, '18-Dec-23', 10, 20, 30, 'Web Developer', 50, 1, 0),
(9, '18-Dec-23', 10, 20, 30, 'Web Developer', 50, 1, 0),
(10, NULL, 10, 10, 10, 'Web Developer', 50, 1, 1),
(11, '18-Dec-23', 10, 20, 30, 'Web Developer', 50, 1, 0),
(12, '18-Dec-23', 10, 20, 30, 'Web Developer', 50, 1, 1),
(18, '29-Dec-23', 10, 20, 30, 'Web Developer', 50, 1, 0),
(19, '01-Jan-24', 10, 20, 30, 'Web Developer', 30, 1, 0),
(20, '02-Jan-24', 10, 20, 30, 'Web Developer', 30, 1, 0),
(21, '03-Jan-24', 10, 20, 30, 'Web Developer', 50, 1, 0),
(22, '07-Feb-24', 10, 20, 30, 'Web Developer', 50, 1, 0),
(23, NULL, 10, 20, 30, 'Web Developer', 50, 1, 0),
(24, '14-Feb-24', 10, 20, 30, 'Software Engineer', 70, 1, 0),
(25, '28-Feb-24', 10, 20, 30, 'Software Engineer', 50, 1, 0),
(26, '01-Mar-24', 10, 20, 30, 'Software Engineer', 50, 1, 0),
(27, '13-Mar-24', 10, 20, 30, 'Software Engineer', 50, 1, 0),
(28, '05-Dec-24', 10, 20, 30, 'Cloud Engineer', 50, 1, 0),
(29, '29-May-24', 0, 15, 35, 'Data Scientist', 60, 1, 0),
(30, '29-May-24', 0, 15, 35, 'Web Developer', 60, 1, 0),
(31, '05-Jun-24', 0, 0, 70, 'Web Developer', 50, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `technical_test`
--

CREATE TABLE `technical_test` (
  `id` int NOT NULL,
  `question` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `type` enum('Web Developer','Cloud Engineer','Software Engineer','Data Scientist','Python Developer') COLLATE utf8mb4_general_ci DEFAULT NULL,
  `option_1` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `option_2` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `option_3` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `option_4` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `answer` varchar(500) COLLATE utf8mb4_general_ci NOT NULL,
  `program` enum('true','false') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'false'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `technical_test`
--

INSERT INTO `technical_test` (`id`, `question`, `type`, `option_1`, `option_2`, `option_3`, `option_4`, `answer`, `program`) VALUES
(469, 'Amazon Elastic Compute Cloud (Amazon EC2) does which of the following?', 'Software Engineer', 'Provides customers with an isolated section of the AWS cloud where they can launch AWS resources\nin a virtual network that they define', 'Provides resizable computing capacity in the cloud', 'Provides a webservice allowing customers to easily setup, operate and scale database systesm on cloud.', 'Provides a simple webservice interface that customers can use to stor', 'Provides resizable computing capacity in the cloud', 'false'),
(470, 'In Amazon S3 storage option what is the acronym of RRS', 'Software Engineer', 'Reduced Redundancy Storage', 'Regulatory Resources Storage', 'Reduced Reaction Storage', 'Redundant Research Storage', 'Redundant Research Storage', 'false'),
(471, 'Which of the following functions does Amazon Elastic Beanstalk automates.', 'Software Engineer', 'Application deployment', 'Auto-scaling', 'Capacity provisioning', 'All the Above', 'All the Above', 'false'),
(472, 'Which of the following is the Container Orchestrators.', 'Software Engineer', 'Vault', 'Docker Swarm and Kubernetes', 'Buckets', 'Ansible', 'Docker Swarm and Kubernetes', 'false'),
(473, 'Which of the following is Kubernetes hosted solutions', 'Software Engineer', 'Google Compute Engine', 'Google Container Engine', 'Oracle Compute Engine', 'Amazon ECS', 'Google Container Engine', 'false'),
(474, 'In Kubernetes, what does minikube mean?', 'Software Engineer', 'Set up an All-in-One Kubernetes cluster on a workstation', 'Set up a multi-node cluster', 'Set-up etcd cluster', 'None of the above', 'Set up an All-in-One Kubernetes cluster on a workstation', 'false'),
(475, 'Which of the following commands do you use to open up a proxy port on localhost for the kubernets cluster.', 'Software Engineer', 'Kubectl create', 'Kubectl proxy', 'Kubectl localhost', 'Kubectl proxy create', 'Kubectl proxy', 'false'),
(476, 'What are the features of Ingress when configured with kubernetes', 'Software Engineer', 'Name based virtual hosting', 'path based routing', 'Custom rules definition', 'All the Above', 'All the Above', 'false'),
(477, 'Which is the enterprise-grade cluster management solution from Docker, using which you can manage your whole cluster.', 'Software Engineer', 'Docker Swarn', 'Docker Hub', 'Docker Universal Control Plane', 'Docker Compose', 'Docker Universal Control Plane', 'false'),
(478, 'Using which of the following Docker tools, you will be able to define and run multi container docker applications', 'Software Engineer', 'Docker Swarn', 'Docker Hub', 'Docker Universal Control Plane', 'Docker Compose', 'Docker Compose', 'false'),
(479, 'Following Docker command: docker exec -it &lt;container_id&gt; bash is used to:', 'Software Engineer', 'Activate default VM machine with bash shell', 'Execute an interactive bash shell on the container', 'Build an image with bash shell', 'Commit changes done in an docker image', 'Execute an interactive bash shell on the container', 'false'),
(480, 'When you run a docker container, you can configure it to run in', 'Software Engineer', 'Detached mode only', 'Foreground mode only', 'Either Detached mode or Foreground mode', 'None of the above', 'Either Detached mode or Foreground mode', 'false'),
(481, 'When working with Dockers, which is the file used to configure the application services', 'Software Engineer', 'Develops', 'YAML', 'PyCon', 'SVC', 'YAML', 'false'),
(482, 'What happens when you execute this command docker run debian /bin/sh', 'Software Engineer', 'A Prompt from the shell of created container will be thrown to you', 'A Container is created and then exited immediately', 'A Container is creatd and executes in the detached mode', 'Docker CLI issues an Error like - No Command specified', 'A Container is created and then exited immediately', 'false'),
(483, 'Which of the following format can be used for docker compose', 'Software Engineer', 'SOAP', 'JSON', 'Python', 'None of the Above', 'JSON', 'false'),
(484, 'Amazon ECS is a Service which you can use to run Docker applications on which type of cluster', 'Software Engineer', 'Non Scalable Cluster', 'Scalable Cluster', 'HA Cluster', 'HP Cluster', 'Scalable Cluster', 'false'),
(485, 'In Kubernetes, what is etcd?', 'Software Engineer', 'It is a distributed key value store', 'Lets you store and share data across a distributed cluster of machines.', 'Stores data about your cluster and share it across the Kubernetes control plane.', 'All the Above', 'All the Above', 'false'),
(486, 'From the following list, Choose the Kubernetes Controllers', 'Software Engineer', 'Namespace', 'Relicaset', 'Deployment', 'Both Relicaset and Deployment', 'Both Relicaset and Deployment', 'false'),
(487, 'Kubernetes Cluster data is stored in which of the following?', 'Software Engineer', 'Kube-apiserver', 'etcd', 'kubelet', 'Namespace', 'etcd', 'false'),
(488, 'Select one of the following, that runs as a node agent and watches for the pods that have been assigned to its node in kubernetes.', 'Software Engineer', 'Kubelet', 'kube-proxy', 'kubectl', 'etcd', 'Kubelet', 'false'),
(489, 'Kubernetes supports which of the following runtime containers?', 'Software Engineer', 'docker', 'rkt', 'Both docker and rkt', 'None of the above', 'Both docker and rkt', 'false'),
(490, 'Taints and Tolerations are introducted from which version of kubernetes?', 'Software Engineer', '1.5', '1.6', '1.7', '1.8', '1.8', 'false'),
(491, 'The adoption of DevOps is being driven by factors such as:                                                                                                          i) Use of Agile and other development processes and methodologies ii) Demand for an increased rate of production releases from application and business unit stakeholders iii) Wide availability of virtualised and cloud infrastructure from internal and external providers iv) Increased usage of data centre automation and configuration management tools              Which factors are correct?', 'Software Engineer', 'i), ii) and iii) only', 'ii) and iii) only', 'ii), iii) and iv) only', 'All of the above', 'All of the above', 'false'),
(492, 'Select one of the following which is a structured data store that supports indexing and data queries to both Amazon EC2 and S3 ?', 'Software Engineer', 'CloudWatch', 'Amazon SimpleDB', 'Amazon Cloudfront', 'All of the mentioned', 'Amazon SimpleDB', 'false'),
(493, 'Choose one of the following, that is built on top of a Hadoop framework using the Elastic Compute Cloud ?', 'Software Engineer', 'Amazon Elastic MapReduce', 'Amazon Mechanical Turk', 'Amazon DevPay', 'Multi-Factor Authentication', 'Amazon Elastic MapReduce', 'false'),
(494, 'Which one of the following cloud concept is related to pooling and sharing of resources ?', 'Software Engineer', 'Polymorphism', 'Abstraction', 'Virtualization', 'None of those mentioned', 'Virtualization', 'false'),
(495, 'On Amazon Cloud Service, Select the service that is used for authentication.', 'Software Engineer', 'Amazon Elastic MapReduce', 'Amazon Mechanical Turk', 'Amazon DevPay', 'Multi-Factor Authentication', 'Multi-Factor Authentication', 'false'),
(496, 'To which one of the following service type does Rackspace Cloud Service belong.', 'Software Engineer', 'IaaS', 'SaaS', 'PaaS', 'All of them mentioned', 'IaaS', 'false'),
(497, 'In Cloud Computing, Select one of the following technique used for capacity planning ?', 'Software Engineer', 'Predict the future based on historical trends and other factors', 'Load the system until it is overloaded', 'Deploy or tear down resources to meet your predictions', 'All of them mentioned', 'Load the system until it is overloaded', 'false'),
(498, 'Which one of the following characteristics of Oracle Cloud, refers to the ability of a cloud subscriber to manage their cloud computing requirements without having to contact a human representative of the cloud service provider', 'Software Engineer', 'Rapid elasticity', 'Resource pooling', 'On-demand self service', 'Broad network access', 'On-demand self service', 'false'),
(499, 'Which of the following page in the Oracle Container Console dashboard page is used to manage Docker images that have been pulled from public or private Docker registries for a deployment, and to start containers directly from images?', 'Software Engineer', 'Registries page', 'Images Page', 'Services Page', 'Containers Page', 'Images Page', 'false'),
(500, 'Which of the following is the runnable unit of work in kubernetes?', 'Software Engineer', 'Containers', 'Pods', 'Volumes', 'Webservers', 'Pods', 'false'),
(501, 'Oracle Container Native Application Development platform comprises of which of the following services?', 'Software Engineer', 'Oracle Container Engine', 'Oracle Container Registry', 'Oracle Container Pipeline', 'All of the Above.', 'All of the Above.', 'false'),
(502, 'Which of the following is used to create a Docker image?', 'Software Engineer', 'Docker file', 'Docker Container', 'Docker repository', 'Docker swarm', 'Docker file', 'false'),
(503, 'The Oracle Cloud Stacks are Created in Oracle Cloud by defining', 'Software Engineer', 'Archieve Files', 'Configuration Files', 'Templates', 'Storage Service', 'Templates', 'false'),
(504, 'Which of the following is the essential characteristics of Oracle Cloud Services', 'Software Engineer', 'Measured Service', 'Resource Pooling', 'Rapid Elasticity', 'All the Above', 'All the Above', 'false'),
(505, 'A multi-tenant cloud is a cloud computing architecture that allows customers to share computing resources in which type of cloud', 'Software Engineer', 'Public', 'Private', 'Private and Public', 'None of the Above', 'Private and Public', 'false'),
(506, 'Following Docker command: docker push &lt;user_name&gt;/&lt;repository_name&gt; is used to:', 'Software Engineer', 'Activate default VM machine', 'Push changes done in an docker image into Docker Hub', 'Build an image', 'Commit changes done in an docker image', 'Push changes done in an docker image into Docker Hub', 'false'),
(507, 'Kubernetes provides containers with which of the following lifecycle hooks?', 'Software Engineer', 'PostStart', 'PreStop', 'Both PostStart and PreStop', 'None of the above', 'Both PostStart and PreStop', 'false'),
(508, 'In Kubernetes, Which of the following controller can be used to create/manage Pods that needs to be run one per machine.', 'Software Engineer', 'ReplicaSet', 'DaemonSet', 'Jobs', 'Tasks', 'DaemonSet', 'false'),
(509, 'Select the process that runs on Kubernetes master node.', 'Software Engineer', 'Kubelet', 'Kube-apiserver', 'Kube-proxy', 'Kube-scheduler', 'Kube-apiserver', 'false'),
(510, 'Which of the following are the core Kubernetes objects?', 'Software Engineer', 'Pod', 'Service', 'Volume', 'All of the Above', 'All of the Above', 'false'),
(529, 'command used to delete a table in MySQL', 'Software Engineer', 'DELETE TABLE table_name;', 'DROP TABLE table_name;', 'REMOVE TABLE table_name;', 'ERASE TABLE table_name;', 'DROP TABLE table_name', 'false'),
(530, 'SELECT DISTINCT statement in MySQL is user to?', 'Software Engineer', 'Selects only unique rows from a table', 'Selects only unique columns from a table', 'Selects columns based on a specific condition', 'Selects data in descending order', 'Selects only unique rows from a table', 'false'),
(531, 'The data type that store  date and time in MySQL', 'Software Engineer', 'DATETIME', 'DATE', 'TIMESTAMP', 'TIME', 'DATETIME', 'false'),
(532, 'SELECT COUNT(*) FROM table_name what will this command do?', 'Software Engineer', 'Counts the total no of rows in the DB table', 'Counts distinct values in a column', 'Counts  NULL values in a column', 'Counts  non-numeric values in a column', 'Counts the total no of rows in the DB table', 'false'),
(533, '________SQL keyword used to retrieve data from multi-tables', 'Software Engineer', 'MERGE', 'JOIN', 'CROSS JOIN', 'UNION', 'JOIN', 'false'),
(534, 'The WHERE clause in MySQL is used to', 'Software Engineer', 'orders the retrieved data', 'Filters rows based on a specified condition', 'Groups rows based on a specified column', 'Joins multiple tables together', 'Filters rows based on a specified condition', 'false'),
(535, 'command to add a new column to an existing table', 'Software Engineer', 'ALTER TABLE', 'MODIFY TABLE', 'UPDATE TABLE', 'ADD COLUMN', 'ALTER TABLE', 'false'),
(536, 'command used to change the data/values in the table', 'Software Engineer', 'MODIFY', 'UPDATE', 'ALTER', 'CHANGE', 'UPDATE', 'false'),
(537, 'Use of ORDER BY clause in an SQL statement', 'Software Engineer', 'Filters the rows based on a specified condition', 'Sorts the retrieved data based on a specified column', 'Changes the data type of a column', 'Groups the rows together based on a specified column', 'Sorts the retrieved data based on a specified column', 'false'),
(538, 'SQL function  used to find the highest value in a column', 'Software Engineer', 'MAX()', 'HIGH()', 'GREATEST()', 'TOP()', 'MAX()', 'false'),
(539, '________is default value of the display property in CSS for most elements', 'Software Engineer', 'block', 'inline', 'inline-block', 'flex', 'inline', 'false'),
(540, 'command to apply an external CSS file to an HTML document', 'Software Engineer', '&lt;style src=&quot;styles.css&quot;&gt;', '&lt;link href=&quot;styles.css&quot; rel=&quot;stylesheet&quot;&gt;', '&lt;link src=&quot;styles.css&quot; type=&quot;text/css&quot;&gt;', '&lt;style href=&quot;styles.css&quot;&gt;', '&lt;link href=&quot;styles.css&quot; rel=&quot;stylesheet&quot;&gt;', 'false'),
(541, 'attribute which are used to define the URL of a linked resource in HTML?', 'Software Engineer', 'src', 'link', 'href', 'url', 'href', 'false'),
(542, '_______is an HTML element for inserting a line break', 'Software Engineer', '&lt;break&gt;', '&lt;line&gt;', '&lt;lb&gt;', '&lt;br&gt;', '&lt;br&gt;', 'false'),
(543, 'tag used to create an unordered list in HTML', 'Software Engineer', '&lt;list&gt;', '&lt;ul&gt;', '&lt;ol&gt;', '&lt;li&gt;', '&lt;ul&gt;', 'false'),
(544, 'Variable name in PHP should not starts with -', 'Software Engineer', '! (Exclamation)', '$$ (Dollar)', 'number', 'None of the above', 'None of the above', 'false'),
(545, 'Which method is used to convert  predefined characters to HTML entities.', 'Software Engineer', 'htmlspecialchars(string,flags,character-set,double_encode)', 'htmlspecialchar(string,flags,character-set,double_encode)', 'Htmlspecialchars()', 'htmlspecialchar()', 'h+A4:F4tmlspecialchars(string,flags,character-set,double_encode)', 'false'),
(546, 'Which of the following is used to display the output in PHP?', 'Software Engineer', 'echo', 'write', 'print', 'Both a and c', 'Both a and c', 'false'),
(547, 'Which of the following is used for concatenation in PHP?', 'Software Engineer', '(Pluse +)', '* (Asterisk)', '. (dot)', 'append()', '. (dot)', 'false'),
(548, 'What is the use of isset() function in PHP?', 'Software Engineer', 'The isset() function is used to check whether variable is not set', 'The isset() function is used to check whether the variable is free or not', 'The isset() function is used to check whether the variable is string or not', 'The isset() function is used to check whether variable is set or not', 'The isset() function is used to check whether variable is set or not', 'false'),
(549, 'Which of the following function is used to get the ASCII value of a character in PHP?', 'Software Engineer', 'val()', 'asc()', 'char()', 'chr()', 'chr+A8:F8()', 'false'),
(550, 'Which of the following is a built-in function in PHP that adds a value first from  end of an array?', 'Software Engineer', 'array_push()', 'inend_array()', 'into_array()', 'array_unshift', 'array_unshift', 'false'),
(551, 'which method is used to connect with data base? In  PHP', 'Software Engineer', '$res = mysqli_query($conn,$sql);', '$res = mysql_query($conn,$sql);', '$res = mysqli_query($databaseName);', 'None of the above', '$res = mysqli_query($conn,$sql);', 'false'),
(552, 'which superglobal variable is used to collect form data after submitting an HTML form with the method &quot;got&quot;?', 'Software Engineer', '$_GET', '$_POST', 'Does not exist', '$_FORM', 'Does not exist', 'false'),
(553, 'What is the purpose of the php function `htmlspecialchar()`?', 'Software Engineer', 'Encode special characters in a string to prevent HTML injection', 'Convert a string to uppercase', 'Remove HTML tags from a string', 'Does not Exist', 'Encode special characters in a string to prevent HTML injection', 'false'),
(554, 'Which tag allows you to add a row, when creating a HTML5 based table', 'Software Engineer', '&lt;td&gt; and &lt;/td&gt;', '&lt;th&gt; and &lt;/th&gt;', '&lt;tr&gt; and &lt;/tr&gt;', '&lt;br&gt; and &lt;/br&gt;', '&lt;tr&gt; and &lt;/tr&gt;', 'false'),
(555, 'When creating links in html pages, what is vlink attritube?', 'Software Engineer', 'Virtual link', 'Virtualized link', 'Virtual active link', 'Visited link', 'Visited link', 'false'),
(556, 'In HTML5 form creation page, which of the following tab is used to create combo box', 'Software Engineer', '&lt;list&gt;', '&lt;input type=&quot;list&quot;&gt;', '&lt;select&gt;', '&lt;input type=&quot;combo&quot;&gt;', '&lt;select&gt;', 'false'),
(557, 'Which tag is used to list individual items of an ordered list in HTML5?', 'Software Engineer', '&lt;UL&gt;', '&lt;OL&gt;', '&lt;IL&gt;', '&lt;LI&gt;', '&lt;LI&gt;', 'false'),
(558, 'For checking a regular express in inputs of HTML5 forms which attritube is used?', 'Software Engineer', 'validate input', 'pattern', 'checker', 'validate form', 'pattern', 'false'),
(559, 'Choose the tag used to embed an independent HTML5 document into a current document.', 'Software Engineer', '&lt;div&gt;', '&lt;span&gt;', '&lt;form&gt;', '&lt;iframe&gt;', '&lt;iframe&gt;', 'false'),
(560, 'Which HTML5 element is used to define a multi-line input field?', 'Software Engineer', '&lt;text&gt;', '&lt;textarea&gt;', '&lt;textfields&gt;', '&lt;blocktext&gt;', '&lt;textarea&gt;', 'false'),
(561, 'Which of the following property in CSS3 defines the gap between columns in a multicolumn text flow?', 'Software Engineer', 'column-float', 'column-width', 'column-flow', 'column-gap', 'column-gap', 'false'),
(562, 'Select the rule that is used to define the style for multiple media types in a single embedded CSS3 style sheet', 'Software Engineer', '@media', '@multimedia', '@singlemedia', '@mediaset', '@media', 'false'),
(563, 'Select the correct HTML5 tag which is used to refer to an external style sheet?', 'Software Engineer', '&lt;stylesheet&gt;abc.css&lt;/stylesheet&gt;', '&lt;style&gt;abc.css&lt;/style&gt;', '&lt;link rel=&quot;stylesheet&quot; type=&quot;text/css&quot; href=&quot;abc.css&quot;&gt;', '&lt;style src=&quot;abc.css&quot;&gt;', '&lt;link rel=&quot;stylesheet&quot; type=&quot;text/css&quot; href=&quot;abc.css&quot;&gt;', 'false'),
(564, 'Which HTML5 tag is used to define an internal style sheet in a webpage.', 'Software Engineer', '&lt;script&gt;', '&lt;css&gt;', '&lt;style&gt;', '&lt;style type=&quot;text/css&quot;&gt;', '&lt;style&gt;', 'false'),
(565, 'Using CSS3 how do you add a background color for all &lt;h1&gt; elements?', 'Software Engineer', 'h1.style{background-color:#FFFFFF;}', 'h1{background-color:#FFFFFF;}', 'h1.all{background-color:#FFFFFF;}', 'h1{all.background-color:#FFFFFF;}', 'h1{background-color:#FFFFFF;}', 'false'),
(566, 'Using CSS3 how do you display hyperlinks without underline.', 'Software Engineer', 'a{text-decoration:no-underline;}', 'a{text-decoration:none;}', 'a{decoration:no-underline;}', 'a{underline:none;}', 'a{text-decoration:none;}', 'false'),
(567, 'Using CSS3 how do you make a list that lists its items with squares?', 'Software Engineer', 'list-type:square;', 'list-style-type-square;', 'list:square;', 'list-style:square;', 'list-style-type-square;', 'false'),
(568, 'How do you select all p elements inside a div element using CSS3.', 'Software Engineer', 'div.p', 'div{p}', 'div.p.all', 'div p', 'div p', 'false'),
(569, 'Using CSS3 how to you group selectors?', 'Software Engineer', 'Separate each selector with a space', 'Separate each selector with a semicolon', 'Separate each selector with a comma', 'Separate each selector with a minus sign', 'Separate each selector with a comma', 'false'),
(570, 'Select the correct CSS snippet for making all the &lt;p&gt; elements bold.', 'Software Engineer', 'p{text-size:bold;}', 'p{font-weight:bold;}', '&lt;p style=&quot;font-size:bold;&quot;&gt;', '&lt;p styple=&quot;text-size:bold;&quot;&gt;', 'p{font-weight:bold;}', 'false'),
(571, 'Based on how many Columns is the Bootstrap grid system organized.', 'Software Engineer', '6', '12', '18', '9', '12', 'false'),
(572, 'Choose the Class which shapes an image to a circle in Bootstrap.', 'Software Engineer', '.img-circle', '.img-thumbnail', '.img-round', '.img-rounded', '.img-circle', 'false'),
(573, 'In Bootstrap, how is a standard navigation tab created.', 'Software Engineer', '&lt;ul class = &quot;nav nav-navbar&quot;&gt;', '&lt;ul class = &quot;nav tabs&quot;&gt;', '&lt;ul class = &quot;nav nav-tabs&quot;&gt;', '&lt;ul class = &quot;nav navbar&quot;&gt;', '&lt;ul class = &quot;nav nav-tabs&quot;&gt;', 'false'),
(574, 'In Bootstrap, which plugin is used to cycle through elements, like a slideshow?', 'Software Engineer', 'Scrollspy', 'Marquee', 'Slideshow', 'Carousel', 'Carousel', 'false'),
(575, 'In Bootstrap, which plugin is used to create a modal window?', 'Software Engineer', 'Dialog Box', 'Popup', 'Tooltip', 'Modal', 'Modal', 'false'),
(576, 'In Bootstrap, which class adds a heading to a panel?', 'Software Engineer', '.panel-head', '.panel-header', '.panel-heading', '.panel-head-header', '.panel-heading', 'false'),
(801, 'What does *args syntax represent in Python?', 'Python Developer', 'Represents a tuple of arguments in a function definition', 'Represents optional arguments in a function call', 'Represents keyword arguments in a function call', 'Represents a list of arguments in a function call', 'Represents a tuple of arguments in a function definition', 'false'),
(802, 'What is the purpose of a Python decorator?', 'Python Developer', 'To modify the behavior of a function or method', 'To create new instances of a class', 'To define a subclass', 'To encapsulate data within a class', 'To modify the behavior of a function or method', 'false'),
(803, 'Which of the following statements about list comprehension in Python is TRUE?', 'Python Developer', 'List comprehension can only be used with lists.', 'List comprehension always results in a tuple.', 'List comprehension is more efficient than using a for loop to create a list.', 'List comprehension cannot be nested.', 'List comprehension is more efficient than using a for loop to create a list.', 'false'),
(804, 'What is the key difference between a set and a frozenset in Python?', 'Python Developer', 'A set is immutable while a frozenset is mutable.', 'A set can contain mutable elements while a frozenset cannot.', 'A frozenset is a subtype of set.', 'There is no difference between a set and a frozenset.', 'A set can contain mutable elements while a frozenset cannot.', 'false'),
(805, 'Which of the following is NOT a valid method to open a file in Python?', 'Python Developer', 'open(&quot;file.txt&quot;,&quot;r&quot;)', 'open(&quot;file.txt&quot;,&quot;w&quot;)', 'open(&quot;file.txt&quot;,&quot;x&quot;)', 'open(&quot;file.txt&quot; , &quot;a&quot;)', 'open(&quot;file.txt&quot;,&quot;x&quot;)', 'false'),
(806, 'What is the purpose of the __init__method in Python classes?', 'Python Developer', 'To initialize instance variables of the class', 'To define a class method', 'To delete an instance of the class', 'To inherit from a superclass', 'To initialize instance variables of the class', 'false'),
(807, 'What is the purpose of the  zip() function in Python?', 'Python Developer', 'To merge two lists into a dictionary', 'To concatenate two strings', 'To iterate over two or more iterables in parallel', 'To remove duplicate elements from a list', 'To iterate over two or more iterables in parallel', 'false'),
(808, 'What does the super() function perform in Python?', 'Python Developer', 'Calls the constructor of the superclass', 'Calls the constructor of the current class', 'Calls a method from the superclass', 'Calls a method from the current class', 'Calls the constructor of the superclass', 'false'),
(809, 'What is the purpose of the map() function in Python?', 'Python Developer', 'To apply a function to each element of an iterable and return an iterator', 'To filter elements from an iterable based on a given condition', 'To sort the elements of an iterable', 'To concatenate two or more iterables', 'To apply a function to each element of an iterable and return an iterator', 'false'),
(810, 'What does the enumerate() function in Python perform?', 'Python Developer', 'Returns an iterator containing the elements of an iterable', 'Returns the index and value of each element in an iterable', 'Returns the maximum element of an iterable', 'Returns a reversed version of an iterable', 'Returns the index and value of each element in an iterable', 'false'),
(811, 'What does the de; statement perform in Python?', 'Python Developer', 'Deletes a variable or item from a collection', 'Declares a new variable', 'Assigns a value to a variable', 'Terminates a loop prematurely', 'Deletes a variable or item from a collection', 'false'),
(812, 'What does the import statement perform in Python?', 'Python Developer', 'Imports a module or specific items from a module', 'Defines a new function', 'Declares a class', 'Calls a function from a module', 'Imports a module or specific items from a module', 'false'),
(813, 'What is the purpose of try, except, else, and finally blocks in Python exception handling?', 'Python Developer', 'try is mandatory, except is optional, else is mandatory, and finally is optional.', 'try is mandatory, except is mandatory, else is optional, and finally is optional.', 'try is mandatory, except is optional, else is optional, and finally is mandatory.', 'try is mandatory, except is mandatory, else is mandatory, and finally is mandatory.', 'try is mandatory, except is optional, else is optional, and finally is mandatory.', 'false'),
(814, 'Which of the following is NOT a valid method for iterating over a dictionary in Python?', 'Python Developer', 'Using a for loop directly over the dictionary', 'Using the items() method', 'Using the keys() method', 'Using the values() method', 'Using the values() method', 'false'),
(815, 'What does the * operator do when used with a function parameter in Python?', 'Python Developer', 'It denotes a keyword-only argument.', 'It collects all the positional arguments into a tuple.', 'It collects all the keyword arguments into a dictionary.', 'It multiplies the arguments passed to the function.', 'It collects all the positional arguments into a tuple.', 'false'),
(816, 'In Python, what does the __name__ variable represent when a script is executed?', 'Python Developer', 'It represents the name of the script.', 'It represents the name of the module.', 'It represents the name of the class.', 'It represents the name of the function.', 'It represents the name of the script.', 'false'),
(817, 'What is the purpose of the classmethod decorator in Python?', 'Python Developer', 'It indicates that a method belongs to a class rather than an instance.', 'It is used to define a static method.', 'It converts a method into a generator function.', 'It is used to create a class-level variable.', 'It indicates that a method belongs to a class rather than an instance.', 'false'),
(818, 'In Python, what does the __init__ method return?', 'Python Developer', 'None', '1', '', 'It returns the initialized object itself.', 'None', 'false'),
(819, 'What does the is keyword perform in Python?', 'Python Developer', 'It checks if two objects have the same value.', 'It checks if two objects have the same memory address.', 'It performs a bitwise AND operation.', 'It checks if two objects have the same type.', 'It checks if two objects have the same memory address.', 'false'),
(820, 'What is the purpose of the staticmethod decorator in Python?', 'Python Developer', 'It indicates that a method belongs to a class rather than an instance.', 'It converts a method into a generator function.', 'It is used to define a static method.', 'It is used to create a class-level variable.', 'It is used to define a static method.', 'false'),
(821, 'def outer_function(x):\r\n    def inner_function(y):\r\n        return x + y\r\n    return inner_function\r\n\r\nadd_five = outer_function(5)\r\nresult = add_five(3)\r\nprint(result) What is the output of the following code snippet?', 'Python Developer', '8', '5', '3', '15', '8', 'false'),
(822, 'def multiply(x, y):\r\n    return x * y\r\n\r\nresult = multiply(3, 4)\r\nprint(result) What is the output of the following code snippet?', 'Python Developer', '7', '12', '34', '10', '12', 'false'),
(823, 'def greet(name):\r\n    return &quot;Hello, &quot; + name + &quot;!&quot;\r\n\r\nmessage = greet(&quot;Alice&quot;)\r\nprint(message) What is the output of the given snippet?', 'Python Developer', '&quot;Hello, Alice!&quot;', '&quot;Hello,!&quot;', '&quot;Hello, Alice&quot;', '&quot;Hello, Alice&quot;', '&quot;Hello, Alice!&quot;', 'false'),
(824, 'numbers = [1, 2, 3, 4, 5]\r\nsquared_numbers = [x ** 2 for x in numbers]\r\nprint(squared_numbers) What is the output of the following code snippet?', 'Python Developer', '[1, 4, 9, 16, 25]', '[1, 2, 3, 4, 5]', '[2, 4, 6, 8, 10]', '[1, 3, 5, 7, 9]', '[1, 4, 9, 16, 25]', 'false'),
(825, 'def add(a, b):\r\n    return a + b\r\n\r\nresult = add(5, 5) + add(3, 3)\r\nprint(result)', 'Python Developer', '16', '11', '20', '10', '20', 'false'),
(826, 'def is_even(num):\r\n    return num % 2 == 0\r\n\r\neven_numbers = list(filter(is_even, [1, 2, 3, 4, 5]))\r\nprint(even_numbers)', 'Python Developer', '[1, 3, 5]', '[2, 4]', '[True, False, True, False, True]', '[1, 2, 3, 4, 5]', '[2, 4]', 'false'),
(827, 'def fibonacci(n):\r\n    if n &lt;= 1:\r\n        return n\r\n    else:\r\n        return fibonacci(n-1) + fibonacci(n-2)\r\n\r\nresult = fibonacci(5)\r\nprint(result)', 'Python Developer', '5', '8', '10', '13', '5', 'false'),
(828, 'def power(x, n):\r\n    if n == 0:\r\n        return 1\r\n    elif n % 2 == 0:\r\n        return power(x, n // 2) * power(x, n // 2)\r\n    else:\r\n        return x * power(x, n // 2) * power(x, n // 2)\r\n\r\nresult = power(2, 3)\r\nprint(result)', 'Python Developer', '8', '6', '64', '12', '64', 'false'),
(829, 'def bubble_sort(arr):\r\n    n = len(arr)\r\n    for i in range(n):\r\n        for j in range(0, n-i-1):\r\n            if arr[j] &gt; arr[j+1]:\r\n                arr[j], arr[j+1] = arr[j+1], arr[j]\r\n\r\narr = [64, 34, 25, 12, 22, 11, 90]\r\nbubble_sort(arr)\r\nprint(&quot;Sorted array:&quot;, arr)', 'Python Developer', 'Sorted array: [11, 12, 22, 25, 34, 64, 90]', 'Sorted array: [90, 64, 34, 25, 22, 12, 11]', 'Sorted array: [64, 34, 25, 12, 22, 11, 90]', 'Sorted array: [11, 22, 25, 34, 64, 90]', 'Sorted array: [11, 12, 22, 25, 34, 64, 90]', 'false'),
(830, 'def memoize(func):\r\n    cache = {}\r\n    def wrapper(*args):\r\n        if args not in cache:\r\n            cache[args] = func(*args)\r\n        return cache[args]\r\n    return wrapper\r\n\r\n@memoize\r\ndef fibonacci(n):\r\n    if n &lt;= 1:\r\n        return n\r\n    else:\r\n        return fibonacci(n-1) + fibonacci(n-2)\r\n\r\nresult = fibonacci(10)\r\nprint(result)', 'Python Developer', '34', '55', '89', '144', '55', 'false'),
(831, 'from functools import reduce\r\n\r\nresult = reduce(lambda x, y: x + y, [1, 2, 3, 4, 5])\r\nprint(result)', 'Python Developer', '15', '10', '120', '25', '15', 'false'),
(832, 'from itertools import permutations\r\n\r\nperms = permutations([1, 2, 3])\r\nfor perm in perms:\r\n    print(perm)', 'Python Developer', '(1, 2, 3) (1, 3, 2) (2, 1, 3) (2, 3, 1) (3, 1, 2) (3, 2, 1)', '(1, 2, 3) (2, 1, 3) (3, 2, 1)', '(1, 3, 2) (2, 3, 1) (3, 1, 2)', 'The code will result in an error.', '(1, 2, 3) (1, 3, 2) (2, 1, 3) (2, 3, 1) (3, 1, 2) (3, 2, 1)', 'false'),
(833, 'from math import sqrt\r\n\r\nresult = list(map(lambda x: round(sqrt(x)), [1, 4, 9, 16, 25]))\r\nprint(result)', 'Python Developer', '[1, 2, 3, 4, 5]', '[1, 2, 3, 4, 6]', '[1, 2, 3, 5]', '[0, 2, 3, 4, 5]', '[1, 2, 3, 4, 5]', 'false'),
(834, 'from functools import partial\r\n\r\ndef power(x, n):\r\n    return x ** n\r\n\r\nsquare = partial(power, n=2)\r\ncube = partial(power, n=3)\r\n\r\nprint(square(5))\r\nprint(cube(5))', 'Python Developer', '10\r\n15', '25 125', '5 125', '25 5', '25 125', 'false'),
(835, 'def add(a, b):\r\n    return a + b\r\n\r\ndef subtract(a, b):\r\n    return a - b\r\n\r\nfuncs = [add, subtract]\r\nresult = funcs[0](5, 3)\r\nprint(result)', 'Python Developer', '8', '2', '15', '&quot;add(5, 3)&quot;', '8', 'false'),
(836, 'def square(x):\r\n    return x ** 2\r\n\r\ndef cube(x):\r\n    return x ** 3\r\n\r\noperations = {&quot;square&quot;: square, &quot;cube&quot;: cube}\r\nresult = operations[&quot;cube&quot;](4)\r\nprint(result)', 'Python Developer', '16', '64', '12', '&quot;cube(4)&quot;', '64', 'false'),
(837, 'def outer():\r\n    x = 10\r\n    def inner():\r\n        nonlocal x\r\n        x += 5\r\n        print(x)\r\n    inner()\r\n\r\nouter()', 'Python Developer', '10', '15', '20', 'This code will result in an error.', '15', 'false'),
(838, 'def make_multiplier(n):\r\n    return lambda x: x * n\r\n\r\nmultiply_by_3 = make_multiplier(3)\r\nresult = multiply_by_3(5)\r\nprint(result)', 'Python Developer', '15', '8', '3', '5', '15', 'false'),
(839, 'def partial_sum(n):\r\n    def add(x):\r\n        nonlocal n\r\n        n += x\r\n        return n\r\n    return add\r\n\r\nadd_to_5 = partial_sum(5)\r\nresult = add_to_5(3)\r\nprint(result)', 'Python Developer', '5', '8', '3', '15', '8', 'false'),
(840, 'def outer_function():\r\n    x = 10\r\n    def inner_function():\r\n        x = 20\r\n        print(x)\r\n    inner_function()\r\n    print(x)\r\nouter_function()', 'Python Developer', '20 20', '10 20', '20 10', '10 10', '20 10', 'false'),
(841, 'def foo():\r\n    try:\r\n        return 1\r\n    finally:\r\n        return 2\r\n\r\nresult = foo()\r\nprint(result)', 'Python Developer', '1', '2', 'The code will result in an error.', 'The output cannot be determined.', '2', 'false'),
(842, 'def my_func():\r\n    try:\r\n        print(&quot;Try block&quot;)\r\n    except:\r\n        print(&quot;Except block&quot;)\r\n    else:\r\n        print(&quot;Else block&quot;)\r\n    finally:\r\n        print(&quot;Finally block&quot;)\r\n\r\nmy_func()', 'Python Developer', 'Try block Else block Finally block', 'Try block Finally block', 'Except block\r\nFinally block', 'The code will result in an error.', 'Try block Else block Finally block', 'false'),
(843, 'def func(x, y=5):\r\n    return x + y\r\n\r\nresult = func(3)\r\nprint(result)', 'Python Developer', '8', '15', '3', 'The code will result in an error.', '8', 'false'),
(844, 'def func(x):\r\n    return x &gt; 5\r\n\r\nresult = filter(func, [1, 3, 5, 7, 9])\r\nprint(list(result))', 'Python Developer', '[7, 9]', '[True, True, False, False, False]', '[False, False, False]', '[1, 3, 5, 7, 9]', '[7, 9]', 'false'),
(845, 'from functools import reduce\r\n\r\nresult = reduce(lambda x, y: x * y, [1, 2, 3, 4], 5)\r\nprint(result)', 'Python Developer', '120', '60', '240', '30', '240', 'false'),
(846, 'def foo(x):\r\n    return x / 2\r\n\r\ndef bar(x):\r\n    return x * 2\r\n\r\nfunctions = [foo, bar]\r\nresult = map(lambda func: func(3), functions)\r\nprint(list(result))', 'Python Developer', '[1.5, 6]', '[1.5, 2]', '[6, 1.5]', '[3, 6]', '[1.5, 6]', 'false'),
(847, 'def add(a, b):\r\n    return a + b\r\n\r\ndef subtract(a, b):\r\n    return a - b\r\n\r\ndef calculator(func, a, b):\r\n    return func(a, b)\r\n\r\nresult = calculator(add, 5, 3) + calculator(subtract, 10, 4)\r\nprint(result)', 'Python Developer', '18', '14', '13', '12', '18', 'false'),
(848, 'def outer_function():\r\n    x = 10\r\n    def inner_function():\r\n        nonlocal x\r\n        x = 20\r\n        print(x)\r\n    inner_function()\r\n    print(x)\r\n\r\nouter_function()', 'Python Developer', '10\r\n10', '10 20', '20 10', '20 20', '10 20', 'false'),
(849, 'def func(x):\r\n    return x % 2 == 0\r\n\r\nresult = list(filter(func, [1, 2, 3, 4, 5]))\r\nprint(result)', 'Python Developer', '[1, 3, 5]', '[2, 4]', '[False, True, False, True, False]', '[1, 3, 5]', '[2, 4]', 'false'),
(850, 'def my_func(x):\r\n    return x ** 2\r\n\r\nresult = list(map(my_func, [1, 2, 3, 4]))\r\nprint(result)', 'Python Developer', '[1, 2, 3, 4]', '[1, 4, 9, 16]', '[2, 4, 6, 8]', '[1, 3, 5, 7]', '[1, 4, 9, 16]', 'false'),
(851, 'def func(x):\r\n    return x * 2\r\n\r\nresult = list(map(lambda x: x ** 2, filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5])))\r\nprint(result)', 'Python Developer', '[1, 4, 9, 16, 25]', '[2, 4, 6, 8, 10]', '[4, 16]', '[2, 4]', '[4, 16]', 'false'),
(852, 'def func(x):\r\n    return x * 3\r\n\r\nresult = list(map(func, filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5])))\r\nprint(result)', 'Python Developer', '[1, 3, 5, 7, 9]', '[2, 6]', '[3, 9]', '[4, 12]', '[2, 6]', 'false'),
(853, 'What does the *args and **kwargs syntax represent in Python function definitions?', 'Python Developer', 'They are used to specify required arguments for a function', 'They are used to specify optional arguments for a function', 'They are used to pass a variable number of positional and keyword arguments to a function', 'They are used to define a variable number of parameters for a function', 'They are used to pass a variable number of positional and keyword arguments to a function', 'false'),
(854, 'Which of the following is NOT a valid method to remove an item from a list in Python?', 'Python Developer', 'list.remove(x)', 'list.pop()', 'del list[x]', 'list.clear()', 'list.clear()', 'false'),
(855, 'What is the purpose of the sys.argv list in Python?', 'Python Developer', 'It contains the command-line arguments passed to a Python script.', 'It stores the environment variables of the system.', 'It is used to store the return values of system calls.', 'It is a reserved keyword for future use.', 'It contains the command-line arguments passed to a Python script.', 'false'),
(856, 'What does the strip() method perform in Python?', 'Python Developer', 'Removes all whitespace characters from the beginning and end of a string.', 'Splits a string into a list of substrings based on a delimiter.', 'Reverses the characters of a string.', 'Converts a string to lowercase.', 'Removes all whitespace characters from the beginning and end of a string.', 'false'),
(857, 'def my_func(x):\r\n    return x * 2\r\n\r\nresult = list(map(lambda x: x ** 2, filter(lambda x: x % 2 == 0, map(my_func, [1, 2, 3, 4, 5]))))\r\nprint(result)', 'Python Developer', '[4, 16]', '[1, 4, 9, 16, 25]', '[4, 8, 12, 16, 20]', '[2, 8, 18, 32, 50]', '[4, 16]', 'false'),
(858, 'Which is the correct way to open a file named &quot;data.txt&quot; for writing in Python?', 'Python Developer', 'file = open(&quot;data.txt&quot;, &quot;r&quot;)', 'file = open(&quot;data.txt&quot;, &quot;w&quot;)', 'file = open(&quot;data.txt&quot;, &quot;a&quot;)', 'file = open(&quot;data.txt&quot;, &quot;rw&quot;)', 'file = open(&quot;data.txt&quot;, &quot;w&quot;)', 'false'),
(859, 'my_list = [1, 2, 3, 4, 5]\r\nresult = [x * x for x in my_list if x % 2 == 0]\r\nprint(result)', 'Python Developer', '[1, 4, 9, 16, 25]', '[4, 16]', '[1, 3, 5]', '[4, 16, 36]', '[4, 16]', 'false'),
(860, 'x = [1, 2, 3]\r\ny = x\r\ny.append(4)\r\nprint(x)', 'Python Developer', '[1, 2, 3]', '[1, 2, 3, 4]', '[1, 2, 3, [4]]', 'Error', '[1, 2, 3, 4]', 'false'),
(861, 'x = 5\r\ndef foo():\r\n    global x\r\n    x = 10\r\n    print(x)\r\n\r\nfoo()\r\nprint(x)', 'Python Developer', '5, 5', '10, 10', '10, 5', '5, 10', '10, 10', 'false'),
(862, 'Which of the following is used to merge two dictionaries in Python 3.9 and above?', 'Python Developer', 'dict1.append(dict2)', 'dict1.merge(dict2)', 'dict1 |= dict2', 'dict1 + dict2', 'dict1 |= dict2', 'false'),
(863, 'Which of the following is NOT a valid HTTP method used in web applications?', 'Python Developer', 'PUT', 'DELETE', 'UPDATE', 'POST', 'UPDATE', 'false'),
(864, 'x = 5\r\ny = &quot;10&quot;\r\nprint(x + y) Identify the error in the following code:', 'Python Developer', 'Missing parentheses in the print statement.', 'No error.', 'Mixing integer and string types in the addition operation.', 'Indentation error.', 'Mixing integer and string types in the addition operation.', 'false'),
(865, 'Which data structure in Python is immutable?', 'Python Developer', 'List', 'Set', 'Dictionary', 'Tuple', 'Tuple', 'false'),
(866, 'What is the term used to describe the ability of a class to inherit attributes and methods from another class in Python?', 'Python Developer', 'Encapsulation', 'Inheritance', 'Polymorphism', 'Abstraction', 'Inheritance', 'false'),
(867, 'Which of the following methods removes the last element from a list in Python?', 'Python Developer', 'pop()', 'remove()', 'delete()', 'last()', 'pop()', 'false'),
(868, 'try:\r\n    print(1 / 0)\r\nexcept ZeroDivisionError:\r\n    print(&quot;Division by zero error&quot;)', 'Python Developer', '0', 'Division by zero error', '1', 'No output, raises an error', 'Division by zero error', 'false'),
(869, 'my_func = lambda x: x * 2\r\nprint(my_func(3))', 'Python Developer', '6', '9', '3', '12', '6', 'false'),
(870, 'What mode is used to open a file for reading and writing, creating the file if it does not exist?', 'Python Developer', 'r', 'w', 'a', 'rw', 'w', 'false'),
(871, 'Which module is used to work with regular expressions in Python?', 'Python Developer', 're', 'regex', 'regexpy', 'regexlib', 're', 'false'),
(872, 'double = lambda x: x * 2', 'Python Developer', 'Returns double the input value', 'Returns the square of the input value', 'Returns half the input value', 'Returns the input value unchanged', 'Returns double the input value', 'false'),
(873, 'my_dict = {&quot;a&quot;: 1, &quot;b&quot;: 2, &quot;c&quot;: 3}\r\ndel my_dict[&quot;b&quot;]\r\nprint(my_dict)', 'Python Developer', '{&quot;a&quot;: 1, &quot;c&quot;: 3}', '{&quot;a&quot;: 1, &quot;b&quot;: 2, &quot;c&quot;: 3}', '{&quot;b&quot;: 2}', 'Error', '{&quot;a&quot;: 1, &quot;c&quot;: 3}', 'false'),
(874, 'def greet(name=&quot;World&quot;):\r\n    print(&quot;Hello, &quot; + name + &quot;!&quot;)\r\n    \r\ngreet(&quot;Alice&quot;)', 'Python Developer', '&quot;Hello, Alice!&quot;', '&quot;Hello, World!&quot;', '&quot;Hello, !&quot;', '&quot;Hello, &quot;', '&quot;Hello, Alice!&quot;', 'false'),
(875, 'my_string = &quot;Python&quot;\r\nresult = my_string[::-1]\r\nprint(result)', 'Python Developer', '&quot;Python&quot;', '&quot;nohtyP&quot;', '&quot;Pytho&quot;', '&quot;n&quot;', '&quot;nohtyP&quot;', 'false'),
(876, 'my_list = [1, 2, 3]\r\nmy_list.append([4, 5])\r\nprint(len(my_list))', 'Python Developer', '3', '4', '5', 'Error', '4', 'false'),
(877, 'my_tuple = (1, 2, 3)\r\nresult = my_tuple.index(2)\r\nprint(result)', 'Python Developer', '0', '1', '2', 'Error', '1', 'false'),
(878, 'def func(x):\r\n    return x + 2\r\n\r\nresult = func(3) * func(2)\r\nprint(result)', 'Python Developer', '30', '35', '20', '14', '14', 'false'),
(879, 'Which method is used to search for a pattern within a string using regular expressions in Python?', 'Python Developer', 'find()', 'search()', 'match()', 'locate()', 'search()', 'false'),
(880, 'Which method is used to remove a key-value pair from a dictionary in Python?', 'Python Developer', 'remove()', 'pop()', 'delete()', 'discard()', 'pop()', 'false'),
(881, 'What is the purpose of the __str__ method in Python classes?', 'Python Developer', 'To compare two objects for equality.', 'To convert the object to a string representation.', 'To create a new instance of the class.', 'To execute code when the object is destroyed.', 'To convert the object to a string representation.', 'false'),
(882, 'Which of the following is a correct way to comment out a single line in Python?', 'Python Developer', '/* Comment */', '# Comment', '&lt;!-- Comment --&gt;', '/* Comment', '# Comment', 'false'),
(883, 'How do you open a file in Python for reading and writing?', 'Python Developer', 'file(&quot;example.txt&quot;, &quot;r+&quot;)', 'open(&quot;example.txt&quot;, &quot;rw&quot;)', 'open(&quot;example.txt&quot;, &quot;r+&quot;)', 'file(&quot;example.txt&quot;, &quot;rw&quot;)', 'open(&quot;example.txt&quot;, &quot;r+&quot;)', 'false'),
(884, 'What is the purpose of the elif keyword in Python?', 'Python Developer', 'To end the program', 'To represent &quot;else if&quot; conditions', 'To check if a variable is defined', 'To print output to the console', 'To represent &quot;else if&quot; conditions', 'false'),
(885, 'Which keyword is used for defining a function in Python?', 'Python Developer', 'func', 'define', 'function', 'def', 'def', 'false'),
(886, 'What does the range() function in Python generate?', 'Python Developer', 'A list of numbers', 'A random sequence of characters', 'A range object representing a sequence of numbers', 'A dictionary', 'A range object representing a sequence of numbers', 'false'),
(887, 'How do you define an empty list in Python?', 'Python Developer', 'list()', '[ ]', '{ }', 'empty_list = []', 'list()', 'false'),
(888, 'What does the len() function do in Python?', 'Python Developer', 'Returns the length of a list or string', 'Converts a string to lowercase', 'Checks if a variable is defined', 'Generates a random number', 'Converts a string to lowercase', 'false'),
(889, 'Which data type is immutable in Python?', 'Python Developer', 'List', 'Dictionary', 'Set', 'Tuple', 'Tuple', 'false'),
(890, 'What is the main difference between a set and a frozenset in Python?', 'Python Developer', 'Sets are mutable, while frozensets are immutable', 'Sets can only store numeric values, while frozensets can store any data type', 'Sets have better performance compared to frozensets', 'Frozensets support additional set operations not available in sets', 'Sets are mutable, while frozensets are immutable', 'false'),
(891, 'How can you create an empty set in Python?', 'Python Developer', 'empty_set = set(0)', 'empty_set = {}', 'empty_set = set()', 'empty_set = set([])', 'empty_set = set()', 'false'),
(892, 'In Python, what does the is operator check for when used with objects?', 'Python Developer', 'Checks if two objects have the same values', 'Checks if two objects have the same identity', 'Checks if two objects have the same type', 'Checks if two objects are equal', 'Checks if two objects have the same identity', 'false'),
(893, 'What is the purpose of the getattr() function in Python?', 'Python Developer', 'Retrieves the attribute value of an object', 'Gets the current time and date', 'Generates a random number', 'Converts a string to uppercase', 'Retrieves the attribute value of an object', 'false'),
(894, 'In Python, what is the purpose of the itertools.cycle function?', 'Python Developer', 'Generates an infinite sequence by repeating a iterable', 'Cycles through elements of an iterable a specified number of times', 'Performs circular shifts on a list', 'Creates a cycle-based animation', 'Generates an infinite sequence by repeating a iterable', 'false'),
(895, 'How is multiple inheritance implemented in Python?', 'Python Developer', 'Using interfaces', 'Using the extends keyword', 'Using the mixins concept', 'Using the inherits keyword', 'Using the mixins concept', 'false'),
(896, 'What is the purpose of the functools.partial function in Python?', 'Python Developer', 'Defines a partial function with fixed arguments', 'Applies a function to a list of arguments', 'Creates a partial copy of an object', 'Returns a partial result of a mathematical operation', 'Defines a partial function with fixed arguments', 'false'),
(897, 'What does the locals() function return in Python?', 'Python Developer', 'The local namespace as a dictionary', 'The global namespace as a dictionary', 'The built-in namespace as a dictionary', 'The attributes of an object', 'The local namespace as a dictionary', 'false'),
(898, 'What is the output of the following code?     def foo(x):\r\n    return x + 5\r\n\r\nbar = foo\r\nresult = bar(10)\r\nprint(result)', 'Python Developer', '5', '10', '15', 'Error', '15', 'false'),
(899, 'What is the purpose of the contextlib.suppress function in Python?', 'Python Developer', 'Suppresses all exceptions raised in a context', 'Raises a specific exception in a context', 'Creates a context manager for file handling', 'Suppresses specific exceptions raised in a context', 'Suppresses specific exceptions raised in a context', 'false'),
(900, 'What does the *args syntax in a function definition mean in Python?', 'Python Developer', 'Represents keyword arguments', 'Denotes an arbitrary number of positional arguments', 'Specifies a variable number of required arguments', 'Defines optional arguments with default values', 'Denotes an arbitrary number of positional arguments', 'false'),
(902, 'my_list = [1, 2, 3, 4, 5]\nprint(my_list[1:3])\n', 'Python Developer', '[1, 2]', ' [2, 3]', '[2, 3, 4]', '[1, 3]', ' [2, 3]', 'true'),
(903, 'x = 5\ny = \"Hello\"\nprint(x + y)\n', 'Python Developer', '5Hello', 'TypeError', 'HelloHelloHelloHelloHello', '10', '5Hello', 'true'),
(904, 'Search engine works in the following stage(s)', 'Data Scientist', 'Crawling', 'Optimizing', 'Developing', 'Featuring', 'Crawling', 'false'),
(905, 'Which of the key metrics is/are used by search engines ?', 'Data Scientist', 'Links', 'Social media', 'Linkbonds', 'Demographics', 'Links', 'false'),
(906, 'What are links from other sites called ?', 'Data Scientist', 'Front links', 'Back links', 'Bound links', 'Hide links', 'Back links', 'false'),
(907, 'How to choose the best keywords ?', 'Data Scientist', 'Use long tail keywords', 'Use duplicate keywords', 'Use irrelevent keywords', 'Use content based', 'Use long tail keywords', 'false');
INSERT INTO `technical_test` (`id`, `question`, `type`, `option_1`, `option_2`, `option_3`, `option_4`, `answer`, `program`) VALUES
(908, 'Which of the following comes under the keywords research tools ?', 'Data Scientist', 'SEMRUSH', 'Portal', 'Search engine', 'Google console', 'SEMRUSH', 'false'),
(909, 'What does search engine results pages display as clickable headlines above website URL', 'Data Scientist', 'Search engines', 'Title tags', 'Meta keywords', 'Meta descriptions', 'Title tags', 'false'),
(910, 'In which code of a webpage, a meta description is a short paragraph ?', 'Data Scientist', 'CSS', 'HTML', 'Java', 'C++', 'HTML', 'false'),
(911, 'Browsers and search engines use the Meta tags to gather information about the', 'Data Scientist', 'Search engine', 'Web page', 'Web portal', 'Web browser', 'Webpage', 'false'),
(912, 'Which type of optimization refers to all actions taken outside of the website ?', 'Data Scientist', 'On-page', 'Off-page', 'Both A and B', 'None of the above', 'Off-page', 'false'),
(913, 'A topics popularity overtime can be seen on which Google tool ?', 'Data Scientist', 'Analytics', 'Adwords', 'Trends', 'Searchengine', 'Trends', 'false'),
(914, 'What is the term for the process of optimizing individual web pages to rank higher ?', 'Data Scientist', 'Link building', 'On - page SEO', 'Off page SEO', 'Content marketing', 'On - page SEO', 'false'),
(915, 'Which of the following is a common off page SEO technique ?', 'Data Scientist', 'Internal linking', 'Optimizing Meta tags', 'Creating quality content', 'Guest blogging', 'Guest blogging', 'false'),
(916, 'What is the term for the practice of using keywords excessively in a webpage’s content ?', 'Data Scientist', 'Keyword Stuffing', 'Keyword density', 'Keyword optimization', 'Keyword Relevence', 'Keyword Stuffing', 'false'),
(917, 'Which factor is more important for improving your websites ranking ?', 'Data Scientist', 'Design of the website', 'Quality of the content', 'Colour theme of the website', 'Number of images used', 'Quality of the content', 'false'),
(918, 'What are &quot;ALT TAGS&quot; used for in SEO ?', 'Data Scientist', 'To hide text', 'To encrypt data', 'To describe images', 'To increase visitors.', 'To describe images', 'false'),
(919, 'What is the primary purpose of &quot; internal linking &quot; in SEO ?', 'Data Scientist', 'Secure website data.', 'Link external websites', 'Link pages within websites', 'Link social media accounts', 'Link pages within websites', 'false'),
(920, 'What is Google Humming bird  ?', 'Data Scientist', 'Tool for creating websites', 'App for managing ads', 'Browser developed by google', 'Googles search algorithm', 'Googles search algorithm', 'false'),
(921, 'Of the items given, what is the single most important on-page SEO factor ?', 'Data Scientist', 'Number of uses of keywords', 'Use of keywords in meta title', 'Use of key word in headings', 'Use of keyword in title tag', 'Use of keyword in title tag', 'false'),
(922, 'Which of the following should be done for On-Page SEO ?', 'Data Scientist', '2% keyword density', '200 characters on description', '5 line paragraph', 'Internal linking', 'Internal linking', 'false'),
(923, 'Which of these is the Black hat SEO ?', 'Data Scientist', 'Link building', 'Quality of the content', 'Keyword stuffing', 'Using alt text', 'Keyword stuffing', 'false'),
(924, 'Which of the following HTTP status codes indicates that a webpage has permanently moved to a new location?', 'Data Scientist', '200', '400', '404', '301', '301', 'false'),
(925, 'Which of these algorithms search engine use to rank pages based on high quality content?', 'Data Scientist', 'Hummingbird', 'Lion', 'Penguin', 'Panda', 'Panda', 'false'),
(926, 'Which of the following tools can help you identify technical SEO issues on your website?', 'Data Scientist', 'Google analytics', 'Google search console', 'Moz pro', 'SEMrush', 'Google search console', 'false'),
(927, 'Which of the following elements is important for optimizing images for SEO?', 'Data Scientist', 'Image resolution', 'Alt text', 'File size', 'Image dimensions', 'Alt text', 'false'),
(928, 'Which HTML tag is considered one of the most important for SEO because it defines the main heading of a webpage?', 'Data Scientist', '&lt;h1&gt;', '&lt;title&gt;', '&lt;meta&gt;', '&lt;head&gt;', '&lt;h1&gt;', 'false'),
(929, 'What is the purpose of the &lt;meta&gt; tag in web pages with the &quot;robots&quot; attribute set to &quot;noindex&quot; in HTML?', 'Data Scientist', 'It specifies the character encoding', 'Includes keywords for to index.', 'Prevents search engines from indexing', 'Defines the main heading', 'Prevents search engines from indexing', 'false'),
(930, 'What is the term used for the process of acquiring traffic or attention through social media platforms?', 'Data Scientist', 'Social Media Management', 'Social Media Optimization', 'Social Media Marketing', 'Social Media Advertising', 'Social Media Marketing', 'false'),
(931, 'What is the purpose of using semantic HTML elements like &lt;header&gt;, &lt;footer&gt;, and &lt;nav&gt; from an SEO perspective?', 'Data Scientist', 'Organize the content of the webpage.', 'Improve the visual appearance', 'Increase the keyword density', 'They have no impact on SEO.', 'Organize the content of the webpage.', 'false'),
(932, 'What is the term used for the percentage of followers who take a desired action, such as liking, commenting, or sharing a post?', 'Data Scientist', 'Reach', 'Impressions', 'Engagement rate', 'CTR - Click Through Rate', 'Engagement rate', 'false'),
(933, 'Which Meta Business Tool is commonly used for analyzing the performance of social media posts and campaigns?', 'Data Scientist', 'Meta Insights', 'Meta Ad Manager', 'Meta Business Suite', 'Meta Analytics', 'Meta Insights', 'false'),
(934, 'What type of data does Google Analytics track?', 'Data Scientist', 'Search engine rankings', 'Social media engagement', 'Website traffic and user behavior', 'Email open rates', 'Website traffic and user behavior', 'false'),
(935, 'What are the software programs used by search engines to crawl websites called?', 'Data Scientist', 'Servers', 'Plugins', 'Browsers', 'Spiders or crawlers', 'Spiders or crawlers', 'false'),
(936, 'What is the term used for the process of analyzing social media data to extract meaningful insights and trends?', 'Data Scientist', 'Social media listening', 'Social media monitoring', 'Social media targeting', 'Social media analytics', 'Social media analytics', 'false'),
(937, 'Which search engine feature provides instant suggestions as a user types their search query?', 'Data Scientist', 'Knowledge graph', 'Autocomplete', 'Related searches', 'Filters', 'Autocomplete', 'false'),
(938, 'Which report in Google Analytics provides information about the devices used by website visitors?', 'Data Scientist', 'Acquisition', 'Audience', 'Behaviour', 'Conversions', 'Audience', 'false'),
(939, 'Which metric measures the number of individuals who see a social media post or ad?', 'Data Scientist', 'Reach', 'Impressions', 'Engagement rate', 'CTR - Click Through Rate', 'Reach', 'false'),
(940, 'Which types of advertisements can be displayed through Google AdSense?', 'Data Scientist', 'Only text-based ads', 'Only image-based ads', 'Text, image, and video ads', 'Only pop-up ads', 'Text, image, and video ads', 'false'),
(941, 'How does Google Analytics track website traffic?', 'Data Scientist', 'By monitoring server logs', 'By linking to social media profiles', 'By installing a tracking code snippet', 'By analyzing email campaigns', 'By installing a tracking code snippet', 'false'),
(942, 'Which Google algorithm update penalizes websites with manipulative or spammy tactics to gain higher rankings in search results?', 'Data Scientist', 'Penguin', 'Panda', 'Humming bird', 'Pigeon', 'Penguin', 'false'),
(943, 'What is the main objective of Meta Business Tools in terms of marketing?', 'Data Scientist', 'To increase website traffic', 'To drive sales and conversions', 'To connect with potential investors', 'To entertain users with content', 'To drive sales and conversions', 'false'),
(944, 'Which of the following legal considerations is relevant to search engine optimization (SEO)?', 'Data Scientist', 'Intellectual property rights', 'Contract law', 'Criminal law', 'Environmental law', 'Intellectual property rights', 'false'),
(945, 'What is the primary goal of social media engagement?', 'Data Scientist', 'Increasing website traffic', 'Driving sales directly from social media', 'Building relationships with the audience', 'Boosting brand awareness', 'Building relationships with the audience', 'false'),
(946, 'Which of the following metrics measures the percentage of people who take a specific action after viewing a social media ad?', 'Data Scientist', 'Reach', 'Impressions', 'Engagement rate', 'Conversion rate', 'Reach', 'false'),
(947, 'What does the acronym UGC stand for in the context of social media marketing?', 'Data Scientist', 'Unique Growth Content', 'User-Generated Content', 'Unified Growth Campaigns', 'Universal Graphical Content', 'User-Generated Content', 'false'),
(948, 'What is the purpose of implementing canonical tags in Technical SEO?', 'Data Scientist', 'To prevent duplicate content issues', 'To improve website security', 'To optimize website URLs for search engines', 'To track user interactions', 'To prevent duplicate content issues', 'false'),
(949, 'What is the recommended page load speed for optimal Technical SEO performance?', 'Data Scientist', 'Less than 1 second', 'Less than 3 seconds', 'Less than 10 seconds', 'Less than 5 seconds', 'Less than 3 seconds', 'false'),
(950, 'Which HTTP status code indicates that a webpage has been successfully crawled and indexed by a search engine?', 'Data Scientist', '200', '301', '404', '500', '200', 'false'),
(951, 'Find out the $date value to get date 18-March-2009? \n<?php\n$date=\'D-M-y\';\n$number = \'18-03-2009\';\n$timestamp = strtotime($number);\n$result = date($date, $timestamp);\n\necho $result;\n?>', 'Web Developer', '$date=\'D-M-Y\';', '$date=\'d-m-y\';', '$date=\'d-M-Y\';', '$date=\'D-m-y\';', '$date=\'d-M-Y\';', 'true'),
(953, '\"<?php\n$cars = array(\"\"Volvo\"\", \"\"BMW\"\", \"\"Toyota\"\"); \n$cars[1] = \"\"Ford\"\";\nvar_dump($cars);\n?>\"\n', 'Web Developer', '\"array(3) {   [0]=>   string(5) \"\"Volvo\"\"   [1]=>   string(4) \"\"Ford\"\"   [2]=>   string(6) \"\"Toyota\"\" }\"', '\"array(4) {   [0]=>   string(5) \"\"Volvo\"\"   [1]=>   string(4) \"\"Ford\"\"   [2]=>   string(3) \"\"BMW\"\"   [3]=>   string(6) \"\"Toyota\"\" }\"', '\"array(3) {   [0]=>   string(5) \"\"Volvo\"\"   [1]=>   string(4) \"\"BMW\"\"   [2]=>   string(6) \"\"Toyota\"\" }\"', '\"array(4) {   [0]=>   string(5) \"\"Volvo\"\"   [1]=>   string(4) \"\"BMW\"\"   [2]=>   string(3) \"\"FORD\"\"   [3]=>   string(6) \"\"Toyota\"\" }\"', '\"array(3) {   [0]=>   string(5) \"\"Volvo\"\"   [1]=>   string(4) \"\"Ford\"\"   [2]=>   string(6) \"\"Toyota\"\" }\"', 'true'),
(954, '\"<?php  \n$var1 = \"\"Hello\"\";  \n$var2 = \"\"World\"\";  \necho \"\"$var1$var2\"\";  \n?>  \"\n', 'Web Developer', 'HelloWorld', '\"$var1$var2\"', 'Hello World', '$var1$var2', 'HelloWorld', 'true'),
(955, '\"<?php  \n$a = 0;  \nwhile ($a++)  \n{  \necho \"\"$a\"\";  \n}  \necho $a;  \n?>  \"\n', 'Web Developer', '0', '1', '11', 'None of the above', '1', 'true'),
(956, '\"<?php\n$a = 15;\nfunction show($a) {\n    $a = 20;\n    echo \"\"$a\"\";\n}\nshow($a);\necho \"\"$a\"\";\n?> \"\n', 'Web Developer', '2020', '2015', '1515', '1520', '2015', 'true'),
(958, 'What is the purpose of a search engines index?', 'Data Scientist', 'To display advertisements', 'To store copies of web pages', 'To organize and retrieve information quickly', 'To determine the popularity', 'To organize and retrieve information quickly', 'false'),
(959, 'Which component of a search engines algorithm determines the relevance of web pages to a users search query?', 'Data Scientist', 'Indexing', 'Ranking', 'Crawling', 'Parsing', 'Ranking', 'false'),
(960, 'Which of the following is a factor that affects a websites domain authority?', 'Data Scientist', 'Number of backlinks', 'Page load speed', 'Image optimization', 'Responsive design', 'Number of backlinks', 'false'),
(961, '\"<?php  \n$x = 15;  \n$y = 20;  \nif($x < ++$x  &&  $x < $y++)  \n{  \necho \"\"Hello World\"\";  \n}  \nelse   \n{  \necho \"\"Hii everyone\"\";  \n}  \n?>  \"\n', 'Web Developer', 'Hii everyone', 'Hello World', 'Hello World Hii everyone', 'None of the above', 'Hii everyone', 'true'),
(962, '\"<?php  \n$a = \"\"1\"\";  \nswitch($a)  \n{  \ncase 1:  \necho \"\"Hello\"\";  \ncase 2:  \necho \"\"World\"\";  \ndefault:  \necho \"\" This is PHP \"\";  \n}  \n?>\"\n', 'Web Developer', 'Hello ', 'World', 'This is PHP', 'HelloWorld This is PHP  ', 'HelloWorld This is PHP  ', 'true'),
(963, '\"<?php \n$str = addcslashes(\"\"Hello World!\"\",\"\"W\"\");\necho($str); \n?>\"\n', 'Web Developer', 'Hello World!', 'Hello \\World!', 'Hello \\W\\o\\r\\l\\d!', 'H\\e\\l\\l\\o \\W\\o\\r\\l\\d\\!', 'Hello \\World!', 'true'),
(964, '\"<?php\n$date=\'d-M-Y\';\n$number = \'18-03-2009\';\n$timestamp = strtotime($number);\n$result = date($date, $timestamp);\n$res=date(\'y\', $timestamp); \necho $res++;\n?>\"\n', 'Web Developer', '2009', '9', '10', '2010', '10', 'true'),
(965, '\"$str = \"\"Hello, World!\"\";\necho strlen($str);\"\n', 'Web Developer', '12', '13', '14', '11', '13', 'true'),
(966, '\"$x = 10;\n$y = \"\"5\"\";\n$sum = $x -(- $y);\necho $sum;\"\n', 'Web Developer', '15', '10', '105', '5', '15', 'true'),
(967, '\"<?php\n$numbers = [2, 4, 6, 8, 10];\n$result = array_map(function($num) {\n    return $num * 2;\n}, $numbers)\n\nprint_r($result);\n?> \"\n', 'Web Developer', '[4, 8, 12, 16, 20]', '[2, 4, 6, 8, 10]', '[2, 4, 6, 8, 10, 12]', 'Syntax Error', 'Syntax Error', 'true'),
(968, '\"function fibonacci($n) {\n    return ($n <= 1) ? $n : (fibonacci($n - 1) + fibonacci($n - 2));\n}\n\necho fibonacci(7);\"\n', 'Web Developer', '5', '8', '15', '13', '13', 'true'),
(969, '\"interface Logger {\n    public function log($message);\n}\nclass FileLogger implements Logger {\n    public function log($message) { \n        echo \"\"Message logged to file: $message\"\";\n    }\n}\n$logger = new FileLogger();\n$logger->log(\"\"Error: File not found\"\");\"\n', 'Web Developer', 'Error: File not found', 'Message logged to file: Error: File not found', 'Logger', 'Error', 'Message logged to file: Error: File not found ', 'true'),
(970, '\"$number = 9.75;\n$rounded = round($number, 1);\n\necho $rounded;\"\n', 'Web Developer', '10', '9.8', '9.7', '9', '9.8', 'true'),
(971, '\"<?php\nfunction foo(&$var) {\n    $var++;\n}\n\n$num = 5;\nfoo($num);\n\necho $num;\n\n\n?>\"\n', 'Web Developer', '5', '6', 'Error', '&$var', '6', 'true'),
(972, 'Variable name in PHP should not starts with -', 'Web Developer', '! (Exclamation)', '$$ (Dollar)', 'number', 'None of the above', 'None of the above', 'false'),
(973, 'Which method is used to convert  predefined characters to HTML entities.', 'Web Developer', 'htmlspecialchars(string,flags,character-set,double_encode)', 'htmlspecialchar(string,flags,character-set,double_encode)', 'Htmlspecialchars()', 'htmlspecialchar()', 'h+A4:F4tmlspecialchars(string,flags,character-set,double_encode)', 'false'),
(974, 'Which of the following is used to display the output in PHP?', 'Web Developer', 'echo', 'write', 'print', 'Both a and c', 'Both a and c', 'false'),
(975, 'Which of the following is used for concatenation in PHP?', 'Web Developer', '(Pluse +)', '* (Asterisk)', '. (dot)', 'append()', '. (dot)', 'false'),
(976, 'What is the use of isset() function in PHP?', 'Web Developer', 'The isset() function is used to check whether variable is not set', 'The isset() function is used to check whether the variable is free or not', 'The isset() function is used to check whether the variable is string or not', 'The isset() function is used to check whether variable is set or not', 'The isset() function is used to check whether variable is set or not', 'false'),
(977, 'Which of the following function is used to get the ASCII value of a character in PHP?', 'Web Developer', 'val()', 'asc()', 'char()', 'chr()', 'chr+A8:F8()', 'false'),
(978, 'Which of the following is a built-in function in PHP that adds a value first from  end of an array?', 'Web Developer', 'array_push()', 'inend_array()', 'into_array()', 'array_unshift', 'array_unshift', 'false'),
(979, 'which superglobal variable is used to collect form data after submitting an HTML form with the method &quot;got&quot;?', 'Web Developer', '$_GET', '$_POST', 'Does not exist', '$_FORM', 'Does not exist', 'false'),
(980, 'What is the purpose of the php function `htmlspecialchar()`?', 'Web Developer', 'Encode special characters in a string to prevent HTML injection', 'Convert a string to uppercase', 'Remove HTML tags from a string', 'Does not Exist', 'Encode special characters in a string to prevent HTML injection', 'false'),
(981, 'which method is used to connect with data base? In  PHP', 'Web Developer', '$res = mysqli_query($conn,$sql);', '$res = mysql_query($conn,$sql);', '$res = mysqli_query($databaseName);', 'None of the above', '$res = mysqli_query($conn,$sql);', 'false'),
(982, 'command used to delete a table in MySQL', 'Web Developer', 'DELETE TABLE table_name;', 'DROP TABLE table_name;', 'REMOVE TABLE table_name;', 'ERASE TABLE table_name;', 'DROP TABLE table_name', 'false'),
(983, 'SELECT DISTINCT statement in MySQL is user to?', 'Web Developer', 'Selects only unique rows from a table', 'Selects only unique columns from a table', 'Selects columns based on a specific condition', 'Selects data in descending order', 'Selects only unique rows from a table', 'false'),
(984, 'The data type that store  date and time in MySQL', 'Web Developer', 'DATETIME', 'DATE', 'TIMESTAMP', 'TIME', 'DATETIME', 'false'),
(985, 'SELECT COUNT(*) FROM table_name what will this command do?', 'Web Developer', 'Counts the total no of rows in the DB table', 'Counts distinct values in a column', 'Counts  NULL values in a column', 'Counts  non-numeric values in a column', 'Counts the total no of rows in the DB table', 'false'),
(986, '________SQL keyword used to retrieve data from multi-tables', 'Web Developer', 'MERGE', 'JOIN', 'CROSS JOIN', 'UNION', 'JOIN', 'false'),
(987, 'The WHERE clause in MySQL is used to', 'Web Developer', 'orders the retrieved data', 'Filters rows based on a specified condition', 'Groups rows based on a specified column', 'Joins multiple tables together', 'Filters rows based on a specified condition', 'false'),
(988, 'command to add a new column to an existing table', 'Web Developer', 'ALTER TABLE', 'MODIFY TABLE', 'UPDATE TABLE', 'ADD COLUMN', 'ALTER TABLE', 'false'),
(989, 'command used to change the data/values in the table', 'Web Developer', 'MODIFY', 'UPDATE', 'ALTER', 'CHANGE', 'UPDATE', 'false'),
(990, 'Use of ORDER BY clause in an SQL statement', 'Web Developer', 'Filters the rows based on a specified condition', 'Sorts the retrieved data based on a specified column', 'Changes the data type of a column', 'Groups the rows together based on a specified column', 'Sorts the retrieved data based on a specified column', 'false'),
(991, 'SQL function  used to find the highest value in a column', 'Web Developer', 'MAX()', 'HIGH()', 'GREATEST()', 'TOP()', 'MAX()', 'false'),
(992, '________is default value of the display property in CSS for most elements', 'Web Developer', 'block', 'inline', 'inline-block', 'flex', 'inline', 'false'),
(993, 'command to apply an external CSS file to an HTML document', 'Web Developer', '&lt;style src=&quot;styles.css&quot;&gt;', '&lt;link href=&quot;styles.css&quot; rel=&quot;stylesheet&quot;&gt;', '&lt;link src=&quot;styles.css&quot; type=&quot;text/css&quot;&gt;', '&lt;style href=&quot;styles.css&quot;&gt;', '&lt;link href=&quot;styles.css&quot; rel=&quot;stylesheet&quot;&gt;', 'false'),
(994, 'attribute which are used to define the URL of a linked resource in HTML?', 'Web Developer', 'src', 'link', 'href', 'url', 'href', 'false'),
(995, '_______is an HTML element for inserting a line break', 'Web Developer', '&lt;break&gt;', '&lt;line&gt;', '&lt;lb&gt;', '&lt;br&gt;', '&lt;br&gt;', 'false'),
(996, 'tag used to create an unordered list in HTML', 'Web Developer', '&lt;list&gt;', '&lt;ul&gt;', '&lt;ol&gt;', '&lt;li&gt;', '&lt;ul&gt;', 'false'),
(997, '\"function generatorExample() {\n    for ($i = 1; $i <= 3; $i++) {\n        yield $i;\n    }\n}\n\n$generator = generatorExample();\n\nforeach ($generator as $value) {\n    echo $value . \"\" \"\";\n}\"\n', 'Web Developer', '1 2 3', '123', 'generatorExample', 'Error', '1 2 3', 'true'),
(998, '\"class CustomException extends Exception {}\n\nfunction myFunction() {\n    throw new CustomException(\"\"Custom Error\"\");\n}\n\ntry {\n    myFunction();\n} catch (CustomException $e) {\n    echo $e->getMessage();\n}\"\n', 'Web Developer', 'Custom Error', 'Exception', 'Error', 'CustomException', 'Custom Error', 'true'),
(999, '\"class MyClass {\n    private $value = 10;\n\n    public function __get($name) {\n        return \"\"Getting $name\"\";\n    }\n}\n\n$obj = new MyClass();\necho $obj->value;\"\n', 'Web Developer', 'Getting value', '10', 'MyClass', 'Error', 'Getting value', 'true'),
(1000, '\"function multiplyByTwo($num) {\n    return $num * 2;\n}\n\n$numbers = [1, 2, 3, 4, 5];\n$result = array_map(\'multiplyByTwo\', $numbers);\n\nprint_r($result);\"\n', 'Web Developer', '[2, 4, 6, 8, 10]', '[1, 2, 3, 4, 5]', '[2, 4, 8, 16, 32]', 'Error', '[2, 4, 6, 8, 10]+B34A34A34:F34A34:F34', 'true'),
(1001, '\"function myFunction(&$param) {\n    $param = $param * 2;\n}\n\n$num = 7;\nmyFunction($num);\n\necho $num;\"\n', 'Web Developer', '14', '7', 'Error', '&$param', '14', 'true'),
(1002, '\"class MyClass {\n    private $value;\n\n    public function __construct($value = null) {\n        $this->value = $value ?? 10;\n    }\n\n    public function getValue() {\n        return $this->value;\n    }\n}\n\n$obj = new MyClass();\necho $obj->getValue();\"\n', 'Web Developer', '10', 'Error', 'MyClass', 'null', '10+B36A36A36:F36A36:F36', 'true'),
(1003, '\"$myString = \"\"Hello, World!\"\";\n$substring = substr($myString, 0, 5);\n\necho $substring;\"\n', 'Web Developer', 'Hello', 'Hello,  ', 'Hello, World!', 'Error', 'Hello', 'true'),
(1004, '\"$numbers = [1, 2, 3, 4, 5];\n$filtered = array_map(function($value) {\n    return $value > 2 ? $value : null;\n}, $numbers);\n\nprint_r($filtered);\"\n', 'Web Developer', '[1, 2, 3, 4, 5]', '[3, 4, 5]', '[null, null, 3, 4, 5]', 'Error', '[null, null, 3, 4, 5]', 'true'),
(1005, '\"$myArray = [\'bananna\', \'bannana\', \'banana\'];\n$reversed = array_reduce(array_reverse($myArray), function($carry, $item) {\n    return $carry . $item . \' \';\n}, \'\');\n\necho $reversed;\"\n', 'Web Developer', 'banana bannana bananna', 'bananna bannana banana', 'banana banana bananna', 'bananna banana bannana', 'banana bannana bananna', 'true'),
(1006, '\"$myString = \"\"PHP is a server-side scripting language.\"\";\n$wordCount = preg_match_all(\'/\\b(\\w+)\\b/\', $myString, $matches);\n\necho $wordCount;\"\n', 'Web Developer', '6', '7', '8', 'Error', '7', 'true'),
(1007, '\"$filename = \"\"example.txt\"\";\nif (file_exists($filename)) {\n    echo \"\"File $filename exists.\"\";\n} else {\n    echo \"\"File $filename does not exist.\"\";\n}\"\n', 'Web Developer', 'File example.txt exists.', 'File example.txt does not exist.', 'example.txt', 'Error', 'File example.txt does not exist.', 'true'),
(1008, '\"<?php\n$numbers = [2, 4, 6, 8, 10];\n$sum = array_reduce($numbers, function($carry, $item) {\n    return $item % 2 == 0 ? $carry + (++$item) : $carry++ % 3 == 0 ? $carry + ($item++) :  ;\n}, 1);\n\necho $sum;\n?>\"\n', 'Web Developer', '30', '35', '36', 'Error', 'Error', 'true'),
(1009, '\"$number = 123;\n$binary = decbin($number);\n\necho $binary;\"\n', 'Web Developer', '1111101', '1000101', '123', 'None of the above', '1111101', 'true'),
(1010, '\"$myArray = [\'apple\', \'banana\', \'cherry\'];\n$first_array = array_rand($myArray);\n\necho $myArray[$first_array];\"\n', 'Web Developer', 'A random element from the array', 'apple', 'banana', 'apple banana cherry', 'A random element from the array', 'true'),
(1011, '\"class MathOperations {\n    public static function power($base, $exponent) {\n        return pow($base, $exponent);\n    }\n}\n\n$result = MathOperations::power(2, 3);\necho $result;\"\n', 'Web Developer', '8', '2^3', '6', 'Error', '8', 'true'),
(1012, '\"$numbers = [2, 4, 6, 8, 10];\n$result = array_reduce($numbers, function($carry, $item) {\n    return $carry * $item;\n}, 1);\n\necho $result;\"\n', 'Web Developer', '3840', '120', '240', 'Error', '3840', 'true'),
(1013, '\"function divide($a, $b) {\n    if ($b == 0) {\n        throw new Exception(\"\"Cannot divide by zero\"\");\n    }\n    return $a / $b;\n}\n\ntry {\n    echo divide(10, 2);\n    echo divide(8, 0);\n} catch (Exception $e) {\n    echo \"\"Caught exception: \"\" . $e->getMessage();\n}\"\n', 'Web Developer', '5Caught exception: Cannot divide by zero', '58', '5', 'Error', '5Caught exception: Cannot divide by zero', 'true'),
(1014, '\"class Counter {\n    private static $count = 0;\n\n    public static function increment() {\n        self::$count++;\n    }\n\n    public static function getCount() {\n        return self::$count;\n    }\n}\n\nCounter::increment();\nCounter::increment();\nCounter::increment();\necho Counter::getCount();\"\n', 'Web Developer', '0', '1', '3', '2', '3', 'true'),
(1015, '\"<?PHP\n ECHO CHR(52);\n?>\"\n', 'Web Developer', '1', '2', '3', '3', '4', 'true'),
(1016, '\"<?PHP\n ECHO ORD(“hi”);\n?>\"\n', 'Web Developer', '104', '103', '106', '209', '104', 'true'),
(1017, '\"<?php\nfunction outerFunction() {\n    $value = 10;\n\n    return function() use ($value) {\n        return $value;\n    };\n}\n\n$closure = outerFunction();\n$value = 20;\necho $closure($value);\n\n?>\"\n', 'Web Developer', '10', '20', '30', 'Error', '10', 'true'),
(1018, '<h1>This is <span style=\"color: blue;\">Blue</span></h1>    What does the above HTML code do?\n', 'Web Developer', ' changes the background color of the heading to blue', 'It changes the font of the text inside the heading to blue.', 'It creates a heading with blue-colored text for the word \"Blue\".', 'It creates a link to a page named \"Blue\".', 'It creates a heading with blue-colored text for the word \"Blue\".', 'true'),
(1019, '\"<ul>\n  <li>Item 1</li>\n  <li>Item 2</li>\n  <li>Item 3</li>\n</ul>           What does the above HTML code represent?\"\n', 'Web Developer', 'A numbered list.', 'it makes an unordered list.', 'it makes definition list.', 'makes bulleted list.', 'it makes an unordered list.', 'true'),
(1020, '\".container {\n  width: 80%;\n  margin: 0 auto;\n  padding: 20px;\n  background-color: #f2f2f2;\n}                          What does the above CSS code do?\"\n', 'Web Developer', 'container with a gray background on the page', 'Adds a border to the container box.', 'alter the font size of the text inside the box.', 'makes a shadow effect to the container.', 'Centers a container with a gray background on the page.', 'true'),
(1021, '\".btn {\n  padding: 10px 20px;\n  border: none;\n  background-color: #3498db;\n  color: white;\n  text-decoration: none;\n  display: inline-block;\n}                      What styling does the above CSS class represent?\"\n', 'Web Developer', 'make button with rounded corners.', 'make a link with a blue background.', ' button with no text.', 'A hyperlink styled as a button.', 'A hyperlink styled as a button.', 'true'),
(1022, '\"<input type=\"\"checkbox\"\" id=\"\"subscribe\"\" name=\"\"subscribe\"\" checked>\n<label for=\"\"subscribe\"\">Subscribe to youtube</label>     What does the above HTML code represent?\"\n', 'Web Developer', 'radio button for subscribing to a youtube.', 'checkbox for subscribing to a youtube.', ' input field for subscribing to a youtube.', 'A dropdown menu for subscription options.', ' checkbox for subscribing to a youtube.', 'true'),
(1023, '\"<table border=\"\"1\"\">\n  <tr>\n    <th>Month</th>\n    <th>Sales</th>\n  </tr>\n  <tr>\n    <td>January</td>\n    <td>$1000</td>\n  </tr>\n</table>    What does the above HTML code create?\"\n', 'Web Developer', 'A table with two rows and one column.', 'A table with one row and two columns.', 'A table with no visible borders.', 'A table with headers and sales data for January.', 'A table with one row and two columns.', 'true'),
(1024, '\".box {\n  width: 200px;\n  height: 200px;\n  border: 1px solid #000;\n  background-color: #f7f7f7;\n  margin: 20px;\n  padding: 10px;\n  box-sizing: border-box;\n}      What does the above CSS code define?\"\n', 'Web Developer', 'A box with a 1px black border and a background color of light gray.', 'A box with no border and a white background.', 'A box with rounded corners.', 'A box with a 10px margin and padding.', 'A box with a 1px black border and a background color of light gray.', 'true'),
(1025, '\".highlight {\n  color: red;\n  font-weight: bold;\n  text-decoration: underline;\n}       What styling does the above CSS class represent?\"\n', 'Web Developer', 'It highlights text in red with bold and underlined formatting.', 'It italicizes text in red.', 'It sets the background color to red.', 'It changes the font size to bold.', 'It highlights text in red with bold and underlined formatting.', 'true'),
(1026, '<img src=\"logo.png\" alt=\"Company Logo\">    What does the above HTML code represent?\n', 'Web Developer', 'Inserts an image with the source \"logo.png\".', 'Creates a link to a PNG file named \"logo\".', 'Inserts a placeholder for a company logo.', 'Generates a button with the text \"Company Logo\".', 'Inserts an image with the source \"logo.png\".', 'true'),
(1027, '\"<form action=\"\"/submit\"\" method=\"\"post\"\">\n  <input type=\"\"text\"\" name=\"\"username\"\" placeholder=\"\"Enter your username\"\">\n  <button type=\"\"submit\"\">Submit</button>\n</form>          What does the above HTML code create?\"\n', 'Web Developer', 'A form to submit data with a username field and a submit button.', 'A login page with a username input field and a submit button.', 'A text field for entering a username.', 'A button without any functionality.', 'A form to submit data with a username field and a submit button.', 'true'),
(1028, '\".nav-links {\n  display: flex;\n  justify-content: space-around;\n  align-items: center;\n}          What does the above CSS code do?\"\n', 'Web Developer', 'Aligns text to the left within a container.', 'Centers items vertically within a container.', 'Creates a navigation bar with evenly spaced links.', 'Positions items in a row with equal space between them.', 'Positions items in a row with equal space between them.', 'true'),
(1029, '\".card {\n  box-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);\n  border-radius: 8px;\n}     What styling does the above CSS class represent?\"\n', 'Web Developer', 'It adds a shadow effect and rounded corners to a card.', 'It sets a background color and border to a card.', 'It changes the font style of a card.', 'It applies padding and margins to a card.', 'It adds a shadow effect and rounded corners to a card.', 'true'),
(1030, '\".heading {\n  font-size: 24px;\n  color: #333;\n  text-align: center;\n  margin-bottom: 20px;\n}        What does the above CSS code define?\"\n', 'Web Developer', 'Styling for a heading element with centered alignment.', 'Styling for a paragraph with a large font size.', 'Styling for a footer with a colored text.', 'Styling for a navigation bar with margins.', 'Styling for a heading element with centered alignment.', 'true'),
(1031, '\".highlighted {\n  background-color: yellow;\n  color: black;\n  font-weight: bold;\n}          What styling does the above CSS class represent?\"\n', 'Web Developer', 'It highlights text with a yellow background and bold black font.', 'It italicizes text with a yellow background.', 'It underlines text with a yellow background.', 'It changes the font color to yellow.', 'It highlights text with a yellow background and bold black font.', 'true'),
(1034, 'Which of the following is NOT a valid method to open a file in Python?', 'Cloud Engineer', 'open(&quot;file.txt&quot;, &quot;r&quot;)', 'open(&quot;file.txt&quot;, &quot;w&quot;)', 'open(&quot;file.txt&quot;, &quot;x&quot;)', 'open(&quot;file.txt&quot;, &quot;a&quot;)', 'open(&quot;file.txt&quot;, &quot;x&quot;)', 'false'),
(1035, '&quot;&lt;?php\r\n$a=array(&quot;&quot;a&quot;&quot;=&gt;&quot;&quot;red&quot;&quot;,&quot;&quot;b&quot;&quot;=&gt;&quot;&quot;green&quot;&quot;);\r\narray_unshift($a,&quot;&quot;blue&quot;&quot;);\r\nprint_r($a);\r\n?&gt;&quot;', 'Cloud Engineer', 'Array ( [0] =&gt; blue [a] =&gt; red [b] =&gt; green )', 'Array (  [a] =&gt; red [b] =&gt; green [c] =&gt; blue)', 'Array (  [a] =&gt; red [b] =&gt; green [2] =&gt; blue)', 'Error', 'Array ( [0] =&gt; blue [a] =&gt; red [b] =&gt; green )', 'false');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `aptitude_test`
--
ALTER TABLE `aptitude_test`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `candidate_list`
--
ALTER TABLE `candidate_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `college_details`
--
ALTER TABLE `college_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `english_test`
--
ALTER TABLE `english_test`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `performance`
--
ALTER TABLE `performance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `program_test`
--
ALTER TABLE `program_test`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `question_pattern`
--
ALTER TABLE `question_pattern`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `technical_test`
--
ALTER TABLE `technical_test`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `aptitude_test`
--
ALTER TABLE `aptitude_test`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `candidate_list`
--
ALTER TABLE `candidate_list`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=280;

--
-- AUTO_INCREMENT for table `college_details`
--
ALTER TABLE `college_details`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `english_test`
--
ALTER TABLE `english_test`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `Id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `performance`
--
ALTER TABLE `performance`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=208;

--
-- AUTO_INCREMENT for table `program_test`
--
ALTER TABLE `program_test`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `question_pattern`
--
ALTER TABLE `question_pattern`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `technical_test`
--
ALTER TABLE `technical_test`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1036;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
